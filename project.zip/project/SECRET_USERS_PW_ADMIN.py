#!/usr/bin/env python3
"""
Usage:
  python add_user.py users.json alice secret123
"""
import datetime
import sys, json, bcrypt, secrets
from pathlib import Path

def main():    
    if len(sys.argv) < 4:
        if sys.argv[2] != 'SECRET_KEY':
            print(f"Usage: {sys.argv[0]} <file.json> <key> <value>")
            sys.exit(1)

    json_path = Path(sys.argv[1])
    key = sys.argv[2]

    # https://stackoverflow.com/questions/32490629/getting-todays-date-in-yyyy-mm-dd-in-python
    # https://docs.python.org/3.6/library/datetime.html
    # https://docs.python.org/3.6/library/datetime.html#strftime-strptime-behavior 
    if key=='SECRET_KEY':
        value = datetime.datetime.now().strftime('%A')
    else:        
        value = sys.argv[3]

    # Load existing JSON (or start fresh)
    if json_path.exists():
        with open(json_path, "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                data = {}
    else:
        data = {}

    # Hash the value with bcrypt
    hashed = bcrypt.hashpw(value.encode(), bcrypt.gensalt()).decode()
    print(hashed)
    # Update dictionary
    if key=='SECRET_KEY':
        data[key]=hashed
    else:
        if key in data:
            data[key]["password"]=hashed#secrets.token_urlsafe(64)
        else:
            data[key]={"password":hashed, "role":"user"}

    # Save back to file
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

    print(f"Updated {json_path}: set {key} → bcrypt hash")

if __name__ == "__main__":
    main()
