from __future__ import annotations

# you need these three
from typing import Any, Dict, Tuple
from datetime import datetime


# Field-type constants ---------------------------------------------------------
INT      = "int"
FLOAT    = "float"
STR      = "str"
DATE     = "date"


# ----------------------------------------------------------------------------- 
class ValidationError(ValueError):
    """Raised when input data violates a table schema."""


# ----------------------------------------------------------------------------- 
class BaseValidator:
    """
    Base class that knows how to validate a payload against
    the subclass-specific SCHEMA mapping.

    Each subclass must supply:

        SCHEMA: Dict[str, Tuple[field_type, required_bool]]
    """

    SCHEMA: Dict[str, Tuple[str, bool]] = {}  # overridden by subclasses

    # Public helpers -----------------------------------------------------------
    def validate_full(self, data: Dict[str, Any]) -> None:
        """Validate a *create* payload (all required keys must be present)."""
        self._run(data, partial=False)

    def validate_partial(self, data: Dict[str, Any]) -> None:
        """Validate an *update* payload (only supplied keys are checked)."""
        self._run(data, partial=True)

    # Internals ----------------------------------------------------------------
    def _run(self, data: Dict[str, Any], partial: bool) -> None:
        errors = []

        # 1) Required keys (create only) ---------------------------------------
        if not partial:
            missing = [k for k, (_, required) in self.SCHEMA.items()
                       if required and k not in data]
            if missing:
                errors.append(f"Missing required field(s): {', '.join(missing)}")

        # 2) Type / format checks ---------------------------------------------
        for key, value in data.items():
            if key not in self.SCHEMA:            # unknown column
                errors.append(f"Unknown field: {key}")
                continue

            field_type, _ = self.SCHEMA[key]

            if field_type == INT and not isinstance(value, int):
                errors.append(f"{key} must be an int")
            elif field_type == FLOAT and not isinstance(value, (int, float)):
                errors.append(f"{key} must be a number")
            elif field_type == STR and not isinstance(value, str):
                errors.append(f"{key} must be a string")
            elif field_type == DATE:
                if not isinstance(value, str):
                    errors.append(f"{key} must be a date string DD.MM.YYYY")
                else:
                    try:
                        datetime.strptime(value, "%d.%m.%Y")
                    except ValueError:
                        errors.append(f"{key} must be in DD.MM.YYYY format")

        # 3) Report ------------------------------------------------------------
        if errors:
            raise ValidationError("; ".join(errors))


# ----------------------------------------------------------------------------- 
# Validators for every table (copy-pasted from CREATE TABLE statements)

class VendorsValidator(BaseValidator):
    SCHEMA = {
        "name":         (STR,  True),
        "vendor_type":  (STR,  True),
        "status":       (STR,  True),
        "phone":        (STR,  True),
        "email":        (STR,  True),
        "address":      (STR,  True),
        "created_at":   (DATE, True),
        "updated_at":   (DATE, True),
    }


class VendorContactsValidator(BaseValidator):
    SCHEMA = {
        "vendor_id":   (INT,  True),
        "first_name":  (STR,  True),
        "last_name":   (STR,  True),
        "job_title":   (STR,  True),
        "phone":       (STR,  False),
        "email":       (STR,  False),
        "created_at":  (DATE, True),
        "updated_at":  (DATE, True),
    }


class VendorScorecardValidator(BaseValidator):
    SCHEMA = {
        "vendor_id":        (INT,  True),
        "period_start":     (DATE, True),
        "period_end":       (DATE, True),
        "quality_score":    (FLOAT, False),
        "on_time_delivery": (FLOAT, False),
        "defect_rate":      (FLOAT, False),
        "comments":         (STR,   False),
        "created_at":       (DATE,  True),
        "updated_at":       (DATE,  True),
    }


class ContractsValidator(BaseValidator):
    SCHEMA = {
        "vendor_id":      (INT,  True),
        "contract_name":  (STR,  True),
        "start_date":     (DATE, True),
        "end_date":       (DATE, False),
        "renewal_terms":  (STR,  False),
        "status":         (STR,  False),
        "created_at":     (DATE, True),
        "updated_at":     (DATE, True),
    }


class PipelinesValidator(BaseValidator):
    SCHEMA = {
        "pipeline_name": (STR,  True),
        "description":   (STR,  True),
        "created_at":    (DATE, True),
        "updated_at":    (DATE, True),
    }


class PipelineStagesValidator(BaseValidator):
    SCHEMA = {
        "pipeline_id":  (INT,  True),
        "stage_name":   (STR,  True),   # schema said INTEGER but that’s clearly a name
        "stage_order":  (INT,  False),
        "created_at":   (DATE, True),
        "updated_at":   (DATE, True),
    }


class OpportunitiesTaskTicketsValidator(BaseValidator):
    SCHEMA = {
        "pipeline_id":  (INT,  True),
        "stage_id":     (INT,  True),
        "vendor_id":    (INT,  True),
        "title":        (STR,  True),
        "description":  (STR,  True),   # schema said INTEGER; treating as text
        "property_id":  (INT,  True),
        "status":       (STR,  True),
        "priority":     (STR,  False),
        "due_date":     (DATE, True),
        "created_at":   (DATE, True),
        "updated_at":   (DATE, True),
    }


class PropertiesValidator(BaseValidator):
    SCHEMA = {
        "property_name": (STR,  True),
        "address":       (STR,  True),
        "status":        (STR,  True),
        "created_at":    (DATE, True),
        "updated_at":    (DATE, True),
    }


class DocumentsValidator(BaseValidator):
    SCHEMA = {
        "vendor_id":   (INT,  True),
        "contract_id": (INT,  True),
        "file_name":   (STR,  True),
        "file_path":   (STR,  True),
        "uploaded_at": (DATE, True),
        "updated_at":  (DATE, True),
    }


class CommunicationsValidator(BaseValidator):
    SCHEMA = {
        "vendor_id":       (INT,  True),
        "date_sent":       (DATE, True),
        "comm_type":       (STR,  True),
        "subject":         (STR,  True),
        "content":         (STR,  True),
        "user_id":         (STR,  False),
        "followup_needed": (STR,  False),
        "created_at":      (DATE, True),
        "updated_at":      (DATE, True),
    }

class OwnerValidator(BaseValidator):
    SCHEMA = {
        "first_name":  (STR,  True),
        "last_name":   (STR,  True),
        "phone":       (STR,  True),
        "email":       (STR,  True),
        "address":     (STR,  True),
        "legal_id":    (STR,  True),
        "created_at":  (DATE, True),
        "updated_at":  (DATE, True),
    }

class OwnerPropertyMapValidator(BaseValidator):
    SCHEMA = {
        "owner_id":    (INT,  True),
        "property_id": (INT,  True),
        "created_at":  (DATE, False),
        "updated_at":  (DATE, False),
    }
