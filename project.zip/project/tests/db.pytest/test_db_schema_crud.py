import sqlite3
from pathlib import Path
import pytest

SCHEMA_FILE = Path(__file__).with_name("schema.sql")
SCHEMA_SQL = SCHEMA_FILE.read_text(encoding="utf-8")


@pytest.fixture
def db_path(tmp_path: Path) -> Path:
    return tmp_path / "crm.sqlite"

@pytest.fixture
def conn(db_path: Path):
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys = ON;")
    con.executescript(SCHEMA_SQL)
    try:
        yield con
    finally:
        con.close()

def insert_baseline(con: sqlite3.Connection):
    cur = con.cursor()
    now = "2025-01-01"

    # vendors
    cur.execute(
        """
        INSERT INTO vendors(name, vendor_type, status, phone, email, address, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?)
        """,
        ("Acme Cleaners", "cleaning", "active", "+30-210-0000000", "acme@example.com", "Main St 1", now, now),
    )
    vendor_id = cur.lastrowid

    # properties
    cur.execute(
        """
        INSERT INTO properties(property_name, address, status, created_at, updated_at)
        VALUES (?,?,?,?,?)
        """,
        ("Apt 101", "Athens", "active", now, now),
    )
    property_id = cur.lastrowid

    # owner
    cur.execute(
        """
        INSERT INTO owner(first_name, last_name, phone, email, address, legal_id, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?)
        """,
        ("Maria", "Papadopoulou", "+30-210-1111111", "maria@example.com", "Athens", "GR123456", now, now),
    )
    owner_id = cur.lastrowid

    # owner_property_map
    cur.execute(
        "INSERT INTO owner_property_map(owner_id, property_id) VALUES (?,?)",
        (owner_id, property_id),
    )
    map_id = cur.lastrowid

    # pipelines
    cur.execute(
        """
        INSERT INTO pipelines(pipeline_name, description, created_at, updated_at)
        VALUES (?,?,?,?)
        """,
        ("Cleaning", "Turnover cleaning pipeline", now, now),
    )
    pipeline_id = cur.lastrowid

    # pipeline_stages
    cur.execute(
        """
        INSERT INTO pipeline_stages(pipeline_id, stage_name, stage_order, created_at, updated_at)
        VALUES (?,?,?,?,?)
        """,
        (pipeline_id, "Scheduled", 1, now, now),
    )
    stage_id = cur.lastrowid

    # contracts
    cur.execute(
        """
        INSERT INTO contracts(vendor_id, contract_name, start_date, end_date, renewal_terms, created_at, updated_at, status)
        VALUES (?,?,?,?,?,?,?,?)
        """,
        (vendor_id, "2025 Cleaning", now, None, "auto-renew", now, now, "signed"),
    )
    contract_id = cur.lastrowid

    # documents
    cur.execute(
        """
        INSERT INTO documents(vendor_id, contract_id, file_name, file_path, uploaded_at, updated_at)
        VALUES (?,?,?,?,?,?)
        """,
        (vendor_id, contract_id, "contract.pdf", "/docs/contract.pdf", now, now),
    )
    document_id = cur.lastrowid

    # vendor_contacts
    cur.execute(
        """
        INSERT INTO vendor_contacts(vendor_id, first_name, last_name, job_title, phone, email, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?)
        """,
        (vendor_id, "Nikos", "K.", "Manager", "+30-210-2222222", "nikos@example.com", now, now),
    )
    contact_id = cur.lastrowid

    # vendor_scorecard
    cur.execute(
        """
        INSERT INTO vendor_scorecard(vendor_id, period_start, period_end, quality_score, on_time_delivery, defect_rate, comments, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?)
        """,
        (vendor_id, "2025-01-01", "2025-03-31", 95, 98, 1.2, "Great start", now, now),
    )
    scorecard_id = cur.lastrowid

    # communications
    cur.execute(
        """
        INSERT INTO communications(vendor_id, date_sent, comm_type, subject, content, user_id, followup_needed, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?)
        """,
        (vendor_id, now, "email", "Kickoff", "Welcome aboard", None, "0", now, now),
    )
    communication_id = cur.lastrowid

    # opportunities_task_tickets
    cur.execute(
        """
        INSERT INTO opportunities_task_tickets(pipeline_id, stage_id, vendor_id, title, description, property_id, status, priority, due_date, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """,
        (pipeline_id, stage_id, vendor_id, "Turnover #1", "Clean after checkout", property_id, "open", "high", "2025-01-02", now, now),
    )
    ticket_id = cur.lastrowid

    con.commit()
    return {
        "vendor_id": vendor_id,
        "property_id": property_id,
        "owner_id": owner_id,
        "map_id": map_id,
        "pipeline_id": pipeline_id,
        "stage_id": stage_id,
        "contract_id": contract_id,
        "document_id": document_id,
        "contact_id": contact_id,
        "scorecard_id": scorecard_id,
        "communication_id": communication_id,
        "ticket_id": ticket_id,
    }

def count(con: sqlite3.Connection, table: str) -> int:
    return con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]


def test_01_create_db_and_insert_all(conn: sqlite3.Connection, db_path: Path):
    assert Path(db_path).exists()

    tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    expected = {
        "vendors","vendor_contacts","vendor_scorecard","contracts","documents",
        "communications","pipelines","pipeline_stages","opportunities_task_tickets",
        "properties","owner","owner_property_map","users"
    }
    assert expected.issubset(tables)

    ids = insert_baseline(conn)

    assert ids["vendor_id"] > 0
    assert count(conn, "vendor_contacts") == 1
    assert count(conn, "vendor_scorecard") == 1
    assert ids["contract_id"] > 0
    assert count(conn, "documents") == 1
    assert count(conn, "communications") == 1
    assert ids["pipeline_id"] > 0 and ids["stage_id"] > 0
    assert count(conn, "opportunities_task_tickets") == 1
    assert ids["property_id"] > 0
    assert ids["owner_id"] > 0 and ids["map_id"] > 0


def test_02_read_all(conn: sqlite3.Connection):
    ids = insert_baseline(conn)

    name = conn.execute("SELECT name FROM vendors WHERE vendor_id=?", (ids["vendor_id"],)).fetchone()[0]
    assert name == "Acme Cleaners"

    pname = conn.execute("SELECT property_name FROM properties WHERE property_id=?", (ids["property_id"],)).fetchone()[0]
    assert pname == "Apt 101"

    v_from_contract = conn.execute("SELECT vendor_id FROM contracts WHERE contract_id=?", (ids["contract_id"],)).fetchone()[0]
    v_from_doc = conn.execute("SELECT vendor_id FROM documents WHERE document_id=?", (ids["document_id"],)).fetchone()[0]
    assert v_from_contract == v_from_doc

    p_from_stage = conn.execute("SELECT pipeline_id FROM pipeline_stages WHERE stage_id=?", (ids["stage_id"],)).fetchone()[0]
    p_from_ticket = conn.execute("SELECT pipeline_id FROM opportunities_task_tickets WHERE opportunity_id=?", (ids["ticket_id"],)).fetchone()[0]
    assert p_from_stage == p_from_ticket

    join_ok = conn.execute(
        "SELECT 1 FROM owner_property_map m JOIN owner o USING(owner_id) JOIN properties p USING(property_id) WHERE m.map_id=?",
        (ids["map_id"],),
    ).fetchone()
    assert join_ok is not None


def test_03_update_all(conn: sqlite3.Connection):
    ids = insert_baseline(conn)

    conn.execute("UPDATE vendors SET status='inactive' WHERE vendor_id=?", (ids["vendor_id"],))
    assert conn.execute("SELECT status FROM vendors WHERE vendor_id=?", (ids["vendor_id"],)).fetchone()[0] == "inactive"

    conn.execute("UPDATE properties SET status='archived' WHERE property_id=?", (ids["property_id"],))
    assert conn.execute("SELECT status FROM properties WHERE property_id=?", (ids["property_id"],)).fetchone()[0] == "archived"

    conn.execute("UPDATE contracts SET status='expired' WHERE contract_id=?", (ids["contract_id"],))
    assert conn.execute("SELECT status FROM contracts WHERE contract_id=?", (ids["contract_id"],)).fetchone()[0] == "expired"

    conn.execute("UPDATE documents SET file_name='contract_v2.pdf' WHERE document_id=?", (ids["document_id"],))
    assert conn.execute("SELECT file_name FROM documents WHERE document_id=?", (ids["document_id"],)).fetchone()[0] == "contract_v2.pdf"

    conn.execute("UPDATE communications SET followup_needed='1' WHERE communication_id=?", (ids["communication_id"],))
    assert conn.execute("SELECT followup_needed FROM communications WHERE communication_id=?", (ids["communication_id"],)).fetchone()[0] == "1"

    conn.execute("UPDATE pipeline_stages SET stage_name='In Progress' WHERE stage_id=?", (ids["stage_id"],))
    assert conn.execute("SELECT stage_name FROM pipeline_stages WHERE stage_id=?", (ids["stage_id"],)).fetchone()[0] == "In Progress"

    conn.execute("UPDATE opportunities_task_tickets SET status='closed' WHERE opportunity_id=?", (ids["ticket_id"],))
    assert conn.execute("SELECT status FROM opportunities_task_tickets WHERE opportunity_id=?", (ids["ticket_id"],)).fetchone()[0] == "closed"

    conn.execute("UPDATE vendor_contacts SET job_title='Director' WHERE contact_id=?", (ids["contact_id"],))
    assert conn.execute("SELECT job_title FROM vendor_contacts WHERE contact_id=?", (ids["contact_id"],)).fetchone()[0] == "Director"

    conn.execute("UPDATE vendor_scorecard SET quality_score=97 WHERE scorecard_id=?", (ids["scorecard_id"],))
    assert conn.execute("SELECT quality_score FROM vendor_scorecard WHERE scorecard_id=?", (ids["scorecard_id"],)).fetchone()[0] == 97

    conn.execute("UPDATE owner SET last_name='P.' WHERE owner_id=?", (ids["owner_id"],))
    assert conn.execute("SELECT last_name FROM owner WHERE owner_id=?", (ids["owner_id"],)).fetchone()[0] == "P."

    conn.execute("UPDATE owner_property_map SET updated_at='2025-02-01' WHERE map_id=?", (ids["map_id"],))
    assert conn.execute("SELECT updated_at FROM owner_property_map WHERE map_id=?", (ids["map_id"],)).fetchone()[0] == "2025-02-01"

    conn.commit()


def test_04_delete_all_in_dependency_order(conn: sqlite3.Connection):
    ids = insert_baseline(conn)

    conn.execute("DELETE FROM opportunities_task_tickets WHERE opportunity_id=?", (ids["ticket_id"],))
    conn.execute("DELETE FROM documents WHERE document_id=?", (ids["document_id"],))
    conn.execute("DELETE FROM communications WHERE communication_id=?", (ids["communication_id"],))
    conn.execute("DELETE FROM vendor_contacts WHERE contact_id=?", (ids["contact_id"],))
    conn.execute("DELETE FROM vendor_scorecard WHERE scorecard_id=?", (ids["scorecard_id"],))
    conn.execute("DELETE FROM owner_property_map WHERE map_id=?", (ids["map_id"],))

    conn.execute("DELETE FROM contracts WHERE contract_id=?", (ids["contract_id"],))
    conn.execute("DELETE FROM pipeline_stages WHERE stage_id=?", (ids["stage_id"],))
    conn.execute("DELETE FROM pipelines WHERE pipeline_id=?", (ids["pipeline_id"],))
    conn.execute("DELETE FROM properties WHERE property_id=?", (ids["property_id"],))
    conn.execute("DELETE FROM owner WHERE owner_id=?", (ids["owner_id"],))

    conn.execute("DELETE FROM vendors WHERE vendor_id=?", (ids["vendor_id"],))

    for table in [
        "vendors","vendor_contacts","vendor_scorecard","contracts","documents",
        "communications","pipelines","pipeline_stages","opportunities_task_tickets",
        "properties","owner","owner_property_map"
    ]:
        assert count(conn, table) == 0, f"{table} not empty after deletes"

    conn.commit()


# Negative tests
def test_05_negative_document_vendor_mismatch(conn: sqlite3.Connection):
    ids = insert_baseline(conn)
    cur = conn.cursor()
    now = "2025-01-01"
    cur.execute(
        """
        INSERT INTO vendors(name, vendor_type, status, phone, email, address, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?)
        """,
        ("Other Vendor", "cleaning", "active", "+30-210-9999999", "other@example.com", "Elsewhere 2", now, now),
    )
    other_vendor = cur.lastrowid

    with pytest.raises(sqlite3.IntegrityError):
        conn.execute(
            """
            INSERT INTO documents(vendor_id, contract_id, file_name, file_path, uploaded_at, updated_at)
            VALUES (?,?,?,?,?,?)
            """,
            (other_vendor, ids["contract_id"], "bad.pdf", "/docs/bad.pdf", now, now),
        )


def test_06_negative_stage_not_in_pipeline(conn: sqlite3.Connection):
    ids = insert_baseline(conn)
    cur = conn.cursor()
    now = "2025-01-01"
    cur.execute(
        "INSERT INTO pipelines(pipeline_name, description, created_at, updated_at) VALUES (?,?,?,?)",
        ("Repairs", "Repair workflow", now, now),
    )
    other_pipeline = cur.lastrowid

    with pytest.raises(sqlite3.IntegrityError):
        cur.execute(
            """
            INSERT INTO opportunities_task_tickets(pipeline_id, stage_id, vendor_id, title, description, property_id, status, priority, due_date, created_at, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """,
            (other_pipeline, ids["stage_id"], ids["vendor_id"], "Mismatch", "Stage not in pipeline", ids["property_id"], "open", None, "2025-01-03", now, now),
        )


def test_07_negative_delete_guards(conn: sqlite3.Connection):
    ids = insert_baseline(conn)

    with pytest.raises(sqlite3.IntegrityError):
        conn.execute("DELETE FROM contracts WHERE contract_id=?", (ids["contract_id"],))

    with pytest.raises(sqlite3.IntegrityError):
        conn.execute("DELETE FROM pipeline_stages WHERE stage_id=?", (ids["stage_id"],))

    with pytest.raises(sqlite3.IntegrityError):
        conn.execute("DELETE FROM properties WHERE property_id=?", (ids["property_id"],))

    with pytest.raises(sqlite3.IntegrityError):
        conn.execute("DELETE FROM vendors WHERE vendor_id=?", (ids["vendor_id"],))


def test_08_negative_fk_missing_parent(conn: sqlite3.Connection):
    now = "2025-01-01"
    with pytest.raises(sqlite3.IntegrityError):
        conn.execute(
            """
            INSERT INTO vendor_scorecard(vendor_id, period_start, period_end, quality_score, on_time_delivery, defect_rate, comments, created_at, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?)
            """,
            (999999, "2025-01-01", "2025-01-31", 80, 90, 2.0, "ghost vendor", now, now),
        )
