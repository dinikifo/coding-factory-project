PRAGMA foreign_keys = ON;

CREATE TABLE "vendors" (
  "vendor_id"   INTEGER PRIMARY KEY AUTOINCREMENT,
  "name"        TEXT NOT NULL,
  "vendor_type" TEXT NOT NULL,
  "status"      TEXT NOT NULL,
  "phone"       TEXT NOT NULL,
  "email"       TEXT NOT NULL,
  "address"     TEXT NOT NULL,
  "created_at"  TEXT NOT NULL,
  "updated_at"  TEXT NOT NULL
);

CREATE TABLE "vendor_contacts" (
  "contact_id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "vendor_id"  INTEGER NOT NULL,
  "first_name" TEXT NOT NULL,
  "last_name"  TEXT NOT NULL,
  "job_title"  TEXT NOT NULL,
  "phone"      TEXT,
  "email"      TEXT,
  "created_at" TEXT NOT NULL,
  "updated_at" TEXT NOT NULL,
  FOREIGN KEY("vendor_id") REFERENCES "vendors"("vendor_id")
);

CREATE TABLE "vendor_scorecard" (
  "scorecard_id"   INTEGER PRIMARY KEY AUTOINCREMENT,
  "vendor_id"      INTEGER NOT NULL,
  "period_start"   TEXT NOT NULL,
  "period_end"     TEXT NOT NULL,
  "quality_score"  NUMERIC DEFAULT 0,
  "on_time_delivery" NUMERIC DEFAULT 0,
  "defect_rate"    NUMERIC DEFAULT 0,
  "comments"       TEXT,
  "created_at"     TEXT NOT NULL,
  "updated_at"     TEXT NOT NULL,
  FOREIGN KEY("vendor_id") REFERENCES "vendors"("vendor_id")
);

CREATE TABLE "contracts" (
  "contract_id"   INTEGER PRIMARY KEY AUTOINCREMENT,
  "vendor_id"     INTEGER NOT NULL,
  "contract_name" TEXT NOT NULL,
  "start_date"    TEXT NOT NULL,
  "end_date"      TEXT,
  "renewal_terms" TEXT NOT NULL,
  "created_at"    TEXT NOT NULL,
  "updated_at"    TEXT NOT NULL,
  "status"        TEXT NOT NULL,
  FOREIGN KEY("vendor_id") REFERENCES "vendors"("vendor_id")
);

CREATE TABLE "documents" (
  "document_id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "vendor_id"   INTEGER NOT NULL,
  "contract_id" INTEGER NOT NULL,
  "file_name"   TEXT NOT NULL,
  "file_path"   TEXT NOT NULL,
  "uploaded_at" TEXT NOT NULL,
  "updated_at"  TEXT NOT NULL,
  FOREIGN KEY("contract_id") REFERENCES "contracts"("contract_id"),
  FOREIGN KEY("vendor_id")   REFERENCES "vendors"("vendor_id")
);

CREATE TABLE "communications" (
  "communication_id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "vendor_id"        INTEGER NOT NULL,
  "date_sent"        TEXT NOT NULL,
  "comm_type"        TEXT NOT NULL,
  "subject"          TEXT NOT NULL,
  "content"          TEXT NOT NULL,
  "user_id"          TEXT,
  "followup_needed"  TEXT,
  "created_at"       TEXT NOT NULL,
  "updated_at"       TEXT NOT NULL,
  FOREIGN KEY("vendor_id") REFERENCES "vendors"("vendor_id")
);

CREATE TABLE "pipelines" (
  "pipeline_id"   INTEGER PRIMARY KEY AUTOINCREMENT,
  "pipeline_name" TEXT NOT NULL,
  "description"   TEXT NOT NULL,
  "created_at"    TEXT NOT NULL,
  "updated_at"    TEXT NOT NULL
);

CREATE TABLE "pipeline_stages" (
  "stage_id"    INTEGER PRIMARY KEY AUTOINCREMENT,
  "pipeline_id" INTEGER NOT NULL,
  "stage_name"  TEXT NOT NULL,
  "stage_order" INTEGER NOT NULL DEFAULT 1,
  "created_at"  TEXT NOT NULL,
  "updated_at"  TEXT NOT NULL,
  FOREIGN KEY("pipeline_id") REFERENCES "pipelines"("pipeline_id")
);

CREATE TABLE "properties" (
  "property_id"   INTEGER PRIMARY KEY AUTOINCREMENT,
  "property_name" TEXT NOT NULL,
  "address"       TEXT NOT NULL,
  "status"        TEXT NOT NULL,
  "created_at"    TEXT NOT NULL,
  "updated_at"    TEXT NOT NULL
);

CREATE TABLE "owner" (
  "owner_id"   INTEGER PRIMARY KEY AUTOINCREMENT,
  "first_name" TEXT NOT NULL,
  "last_name"  TEXT NOT NULL,
  "phone"      TEXT NOT NULL,
  "email"      TEXT NOT NULL,
  "address"    TEXT NOT NULL,
  "legal_id"   TEXT NOT NULL,
  "created_at" TEXT NOT NULL,
  "updated_at" TEXT NOT NULL
);

CREATE TABLE "owner_property_map" (
  "map_id"     INTEGER PRIMARY KEY AUTOINCREMENT,
  "owner_id"   INTEGER NOT NULL,
  "property_id" INTEGER NOT NULL,
  "created_at" TEXT NOT NULL DEFAULT '00.00.0000',
  "updated_at" TEXT NOT NULL DEFAULT '00.00.0000',
  FOREIGN KEY("owner_id")   REFERENCES "owner"("owner_id"),
  FOREIGN KEY("property_id") REFERENCES "properties"("property_id")
);

CREATE TABLE "opportunities_task_tickets" (
  "opportunity_id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "pipeline_id"    INTEGER NOT NULL,
  "stage_id"       INTEGER NOT NULL,
  "vendor_id"      INTEGER NOT NULL,
  "title"          TEXT NOT NULL,
  "description"    TEXT NOT NULL,
  "property_id"    INTEGER NOT NULL,
  "status"         TEXT NOT NULL,
  "priority"       TEXT,
  "due_date"       TEXT NOT NULL,
  "created_at"     TEXT NOT NULL,
  "updated_at"     TEXT NOT NULL,
  FOREIGN KEY("pipeline_id") REFERENCES "pipelines"("pipeline_id"),
  FOREIGN KEY("property_id") REFERENCES "properties"("property_id"),
  FOREIGN KEY("stage_id")    REFERENCES "pipeline_stages"("stage_id"),
  FOREIGN KEY("vendor_id")   REFERENCES "vendors"("vendor_id")
);

CREATE TABLE "users" (
  "userId"   INTEGER PRIMARY KEY AUTOINCREMENT,
  "userName" TEXT UNIQUE,
  "userRole" TEXT NOT NULL
);

-- Triggers

CREATE TRIGGER fk_document_vendor_matches_contract_ins
BEFORE INSERT ON documents
FOR EACH ROW
WHEN (SELECT vendor_id FROM contracts WHERE contract_id = NEW.contract_id) <> NEW.vendor_id
BEGIN
  SELECT RAISE(ABORT, 'document vendor mismatch');
END;

CREATE TRIGGER fk_document_vendor_matches_contract_upd
BEFORE UPDATE OF vendor_id, contract_id ON documents
FOR EACH ROW
WHEN (SELECT vendor_id FROM contracts WHERE contract_id = NEW.contract_id) <> NEW.vendor_id
BEGIN
  SELECT RAISE(ABORT, 'document vendor mismatch');
END;

CREATE TRIGGER fk_opp_stage_matches_pipeline_ins
BEFORE INSERT ON opportunities_task_tickets
FOR EACH ROW
WHEN (SELECT pipeline_id FROM pipeline_stages WHERE stage_id = NEW.stage_id) <> NEW.pipeline_id
BEGIN
  SELECT RAISE(ABORT, 'stage not in pipeline');
END;

CREATE TRIGGER fk_opp_stage_matches_pipeline_upd
BEFORE UPDATE OF stage_id, pipeline_id ON opportunities_task_tickets
FOR EACH ROW
WHEN (SELECT pipeline_id FROM pipeline_stages WHERE stage_id = NEW.stage_id) <> NEW.pipeline_id
BEGIN
  SELECT RAISE(ABORT, 'stage not in pipeline');
END;

CREATE TRIGGER fk_contracts_has_docs_bd
BEFORE DELETE ON contracts
FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM documents d WHERE d.contract_id = OLD.contract_id)
BEGIN
  SELECT RAISE(ABORT,'Delete violates FK: contract still referenced by documents');
END;

CREATE TRIGGER fk_pipeline_stages_has_opp_bd
BEFORE DELETE ON pipeline_stages
FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM opportunities_task_tickets o WHERE o.stage_id = OLD.stage_id)
BEGIN
  SELECT RAISE(ABORT,'Delete violates FK: stage still referenced by opportunities/tasks');
END;

CREATE TRIGGER fk_pipelines_has_children_bd
BEFORE DELETE ON pipelines
FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM pipeline_stages s WHERE s.pipeline_id = OLD.pipeline_id)
   OR EXISTS (SELECT 1 FROM opportunities_task_tickets o WHERE o.pipeline_id = OLD.pipeline_id)
BEGIN
  SELECT RAISE(ABORT,'Delete violates FK: pipeline still referenced');
END;

CREATE TRIGGER fk_properties_has_children_bd
BEFORE DELETE ON properties
FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM owner_property_map m WHERE m.property_id = OLD.property_id)
   OR EXISTS (SELECT 1 FROM opportunities_task_tickets o WHERE o.property_id = OLD.property_id)
BEGIN
  SELECT RAISE(ABORT,'Delete violates FK: property still referenced');
END;

CREATE TRIGGER fk_vendors_has_children_bd
BEFORE DELETE ON vendors
FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM communications c WHERE c.vendor_id = OLD.vendor_id)
   OR EXISTS (SELECT 1 FROM contracts c WHERE c.vendor_id = OLD.vendor_id)
   OR EXISTS (SELECT 1 FROM documents d WHERE d.vendor_id = OLD.vendor_id)
   OR EXISTS (SELECT 1 FROM opportunities_task_tickets o WHERE o.vendor_id = OLD.vendor_id)
   OR EXISTS (SELECT 1 FROM vendor_contacts vc WHERE vc.vendor_id = OLD.vendor_id)
   OR EXISTS (SELECT 1 FROM vendor_scorecard vs WHERE vs.vendor_id = OLD.vendor_id)
BEGIN
  SELECT RAISE(ABORT,'Delete violates FK: vendors row still referenced');
END;
