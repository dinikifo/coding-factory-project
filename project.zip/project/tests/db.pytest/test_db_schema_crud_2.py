import sqlite3
from pathlib import Path
import pytest

SCHEMA_FILE = Path(__file__).with_name("schema.sql")
SCHEMA_SQL = SCHEMA_FILE.read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def db_path(tmp_path_factory) -> Path:
    return tmp_path_factory.mktemp("db") / "crm.sqlite"

@pytest.fixture(scope="module")
def conn_module(db_path: Path):
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys = ON;")
    con.executescript(SCHEMA_SQL)
    yield con
    con.close()

@pytest.fixture
def conn(conn_module: sqlite3.Connection):
    # For safety, wrap each test in a transaction and roll it back,
    # so tests remain isolated even though we reuse the DB file.
    conn_module.execute("BEGIN")
    try:
        yield conn_module
    finally:
        conn_module.execute("ROLLBACK")
def insert_baseline(con: sqlite3.Connection):
    cur = con.cursor()
    now = "2025-01-01"

    # vendors
    cur.execute(
        """
        INSERT INTO vendors(name, vendor_type, status, phone, email, address, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?)
        """,
        ("Acme Cleaners", "cleaning", "active", "+30-210-0000000", "acme@example.com", "Main St 1", now, now),
    )
    vendor_id = cur.lastrowid

    # properties
    cur.execute(
        """
        INSERT INTO properties(property_name, address, status, created_at, updated_at)
        VALUES (?,?,?,?,?)
        """,
        ("Apt 101", "Athens", "active", now, now),
    )
    property_id = cur.lastrowid

    # owner
    cur.execute(
        """
        INSERT INTO owner(first_name, last_name, phone, email, address, legal_id, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?)
        """,
        ("Maria", "Papadopoulou", "+30-210-1111111", "maria@example.com", "Athens", "GR123456", now, now),
    )
    owner_id = cur.lastrowid

    # owner_property_map
    cur.execute(
        "INSERT INTO owner_property_map(owner_id, property_id) VALUES (?,?)",
        (owner_id, property_id),
    )
    map_id = cur.lastrowid

    # pipelines
    cur.execute(
        """
        INSERT INTO pipelines(pipeline_name, description, created_at, updated_at)
        VALUES (?,?,?,?)
        """,
        ("Cleaning", "Turnover cleaning pipeline", now, now),
    )
    pipeline_id = cur.lastrowid

    # pipeline_stages
    cur.execute(
        """
        INSERT INTO pipeline_stages(pipeline_id, stage_name, stage_order, created_at, updated_at)
        VALUES (?,?,?,?,?)
        """,
        (pipeline_id, "Scheduled", 1, now, now),
    )
    stage_id = cur.lastrowid

    # contracts
    cur.execute(
        """
        INSERT INTO contracts(vendor_id, contract_name, start_date, end_date, renewal_terms, created_at, updated_at, status)
        VALUES (?,?,?,?,?,?,?,?)
        """,
        (vendor_id, "2025 Cleaning", now, None, "auto-renew", now, now, "signed"),
    )
    contract_id = cur.lastrowid

    # documents
    cur.execute(
        """
        INSERT INTO documents(vendor_id, contract_id, file_name, file_path, uploaded_at, updated_at)
        VALUES (?,?,?,?,?,?)
        """,
        (vendor_id, contract_id, "contract.pdf", "/docs/contract.pdf", now, now),
    )
    document_id = cur.lastrowid

    # vendor_contacts
    cur.execute(
        """
        INSERT INTO vendor_contacts(vendor_id, first_name, last_name, job_title, phone, email, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?)
        """,
        (vendor_id, "Nikos", "K.", "Manager", "+30-210-2222222", "nikos@example.com", now, now),
    )
    contact_id = cur.lastrowid

    # vendor_scorecard
    cur.execute(
        """
        INSERT INTO vendor_scorecard(vendor_id, period_start, period_end, quality_score, on_time_delivery, defect_rate, comments, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?)
        """,
        (vendor_id, "2025-01-01", "2025-03-31", 95, 98, 1.2, "Great start", now, now),
    )
    scorecard_id = cur.lastrowid

    # communications
    cur.execute(
        """
        INSERT INTO communications(vendor_id, date_sent, comm_type, subject, content, user_id, followup_needed, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?)
        """,
        (vendor_id, now, "email", "Kickoff", "Welcome aboard", None, "0", now, now),
    )
    communication_id = cur.lastrowid

    # opportunities_task_tickets
    cur.execute(
        """
        INSERT INTO opportunities_task_tickets(pipeline_id, stage_id, vendor_id, title, description, property_id, status, priority, due_date, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """,
        (pipeline_id, stage_id, vendor_id, "Turnover #1", "Clean after checkout", property_id, "open", "high", "2025-01-02", now, now),
    )
    ticket_id = cur.lastrowid

    con.commit()
    return {
        "vendor_id": vendor_id,
        "property_id": property_id,
        "owner_id": owner_id,
        "map_id": map_id,
        "pipeline_id": pipeline_id,
        "stage_id": stage_id,
        "contract_id": contract_id,
        "document_id": document_id,
        "contact_id": contact_id,
        "scorecard_id": scorecard_id,
        "communication_id": communication_id,
        "ticket_id": ticket_id,
    }

def count(con: sqlite3.Connection, table: str) -> int:
    return con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]


def test_create_read_update_delete(conn: sqlite3.Connection, db_path: Path):
    assert db_path.exists()

    # CREATE
    ids = insert_baseline(conn)

    # READ key relationships
    assert conn.execute("SELECT name FROM vendors WHERE vendor_id=?", (ids["vendor_id"],)).fetchone()[0] == "Acme Cleaners"
    assert conn.execute("SELECT property_name FROM properties WHERE property_id=?", (ids["property_id"],)).fetchone()[0] == "Apt 101"
    assert conn.execute("SELECT vendor_id FROM contracts WHERE contract_id=?", (ids["contract_id"],)).fetchone()[0] ==            conn.execute("SELECT vendor_id FROM documents WHERE document_id=?", (ids["document_id"],)).fetchone()[0]

    # UPDATE (a few representative ones)
    conn.execute("UPDATE vendors SET status='inactive' WHERE vendor_id=?", (ids["vendor_id"],))
    assert conn.execute("SELECT status FROM vendors WHERE vendor_id=?", (ids["vendor_id"],)).fetchone()[0] == "inactive"

    conn.execute("UPDATE opportunities_task_tickets SET status='closed' WHERE opportunity_id=?", (ids["ticket_id"],))
    assert conn.execute("SELECT status FROM opportunities_task_tickets WHERE opportunity_id=?", (ids["ticket_id"],)).fetchone()[0] == "closed"

    # DELETE in FK-safe order
    conn.execute("DELETE FROM opportunities_task_tickets WHERE opportunity_id=?", (ids["ticket_id"],))
    conn.execute("DELETE FROM documents WHERE document_id=?", (ids["document_id"],))
    conn.execute("DELETE FROM communications WHERE communication_id=?", (ids["communication_id"],))
    conn.execute("DELETE FROM vendor_contacts WHERE contact_id=?", (ids["contact_id"],))
    conn.execute("DELETE FROM vendor_scorecard WHERE scorecard_id=?", (ids["scorecard_id"],))
    conn.execute("DELETE FROM owner_property_map WHERE map_id=?", (ids["map_id"],))
    conn.execute("DELETE FROM contracts WHERE contract_id=?", (ids["contract_id"],))
    conn.execute("DELETE FROM pipeline_stages WHERE stage_id=?", (ids["stage_id"],))
    conn.execute("DELETE FROM pipelines WHERE pipeline_id=?", (ids["pipeline_id"],))
    conn.execute("DELETE FROM properties WHERE property_id=?", (ids["property_id"],))
    conn.execute("DELETE FROM owner WHERE owner_id=?", (ids["owner_id"],))
    conn.execute("DELETE FROM vendors WHERE vendor_id=?", (ids["vendor_id"],))

    # all clear
    for table in [
        "vendors","vendor_contacts","vendor_scorecard","contracts","documents",
        "communications","pipelines","pipeline_stages","opportunities_task_tickets",
        "properties","owner","owner_property_map"
    ]:
        assert count(conn, table) == 0
