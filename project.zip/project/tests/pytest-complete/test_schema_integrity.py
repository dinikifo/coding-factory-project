import sqlite3
import pytest

# -----------------------------
# Helpers for common insertions
# -----------------------------

def insert_ticket_ok(cx, pipeline_id=1, stage_id=10, vendor_id=100, property_id=300, title="T", status="open"):
    ts = "2025-01-01 00:00:00"
    cx.execute(
        """INSERT INTO opportunities_task_tickets(
            ticket_id, pipeline_id, stage_id, vendor_id, property_id, title, description,
            status, priority, due_date, created_at, updated_at
        ) VALUES (
            1000, ?, ?, ?, ?, ?, 'desc', ?, 'low', '2025-01-31', ?, ?
        );""",
        (pipeline_id, stage_id, vendor_id, property_id, title, status, ts, ts),
    )
    cx.commit()

def insert_document(cx, document_id=900, contract_id=500, vendor_id=100, file_name="doc.pdf"):
    ts = "2025-01-01 00:00:00"
    cx.execute(
        """INSERT INTO documents(
            document_id, contract_id, vendor_id, file_name, mime_type, created_at, updated_at
        ) VALUES (?, ?, ?, ?, 'application/pdf', ?, ?);""",
        (document_id, contract_id, vendor_id, file_name, ts, ts),
    )
    cx.commit()

# --------------------------------------------
# 1) Ticket invariant: stage must be in pipeline
#    (trg_ticket_stage_in_pipeline*)
# --------------------------------------------

def test_ticket_insert_stage_not_in_pipeline_raises(cx, base_rows):
    # stage_id=20 belongs to pipeline_id=2, but we pass pipeline_id=1
    with pytest.raises(sqlite3.IntegrityError) as e:
        insert_ticket_ok(cx, pipeline_id=1, stage_id=20)
    assert "stage not in pipeline" in str(e.value).lower()

def test_ticket_insert_happy_path(cx, base_rows):
    # Matching pipeline/stage (1,10)
    insert_ticket_ok(cx, pipeline_id=1, stage_id=10)
    got = cx.execute("SELECT COUNT(*) FROM opportunities_task_tickets WHERE ticket_id=1000;").fetchone()[0]
    assert got == 1

def test_ticket_update_to_mismatched_stage_pipeline_raises(cx, base_rows):
    insert_ticket_ok(cx, pipeline_id=1, stage_id=10)
    with pytest.raises(sqlite3.IntegrityError) as e:
        cx.execute("UPDATE opportunities_task_tickets SET stage_id=20 WHERE ticket_id=1000;")
    assert "stage not in pipeline" in str(e.value).lower()

def test_ticket_update_pipeline_breaks_combo_raises(cx, base_rows):
    insert_ticket_ok(cx, pipeline_id=1, stage_id=10)
    with pytest.raises(sqlite3.IntegrityError) as e:
        cx.execute("UPDATE opportunities_task_tickets SET pipeline_id=2 WHERE ticket_id=1000;")
    assert "stage not in pipeline" in str(e.value).lower()

# --------------------------------------------------
# 2) Document invariant: vendor must match contract
#    (trg_documents_vendor_matches_contract*)
# --------------------------------------------------

def test_document_insert_vendor_mismatch_raises(cx, base_rows):
    # Contract 500 belongs to vendor 100; attempt vendor 200
    with pytest.raises(sqlite3.IntegrityError) as e:
        insert_document(cx, document_id=901, contract_id=500, vendor_id=200)
    assert "document vendor mismatch" in str(e.value).lower()

def test_document_insert_happy_path(cx, base_rows):
    insert_document(cx, document_id=902, contract_id=500, vendor_id=100)
    got = cx.execute("SELECT COUNT(*) FROM documents WHERE document_id=902;").fetchone()[0]
    assert got == 1

def test_document_update_vendor_mismatch_raises(cx, base_rows):
    insert_document(cx, document_id=903, contract_id=500, vendor_id=100)
    with pytest.raises(sqlite3.IntegrityError) as e:
        cx.execute("UPDATE documents SET vendor_id=200 WHERE document_id=903;")
    assert "document vendor mismatch" in str(e.value).lower()

# ---------------------------------------
# 3) Foreign key negative insert coverage
# ---------------------------------------

@pytest.mark.parametrize(
    "table, cols, vals",
    [
        ("opportunities_task_tickets",
         "(ticket_id,pipeline_id,stage_id,vendor_id,property_id,title,description,status,priority,due_date,created_at,updated_at)",
         (1100, 1, 10, 9999, 300, "T", "d", "open", "low", "2025-01-31", "2025-01-01 00:00:00", "2025-01-01 00:00:00")),
        ("opportunities_task_tickets",
         "(ticket_id,pipeline_id,stage_id,vendor_id,property_id,title,description,status,priority,due_date,created_at,updated_at)",
         (1101, 1, 10, 100, 9999, "T", "d", "open", "low", "2025-01-31", "2025-01-01 00:00:00", "2025-01-01 00:00:00")),
        ("documents",
         "(document_id,contract_id,vendor_id,file_name,mime_type,created_at,updated_at)",
         (910, 9999, 100, "f.pdf", "application/pdf", "2025-01-01 00:00:00", "2025-01-01 00:00:00")),
        ("documents",
         "(document_id,contract_id,vendor_id,file_name,mime_type,created_at,updated_at)",
         (911, 500, 9999, "f.pdf", "application/pdf", "2025-01-01 00:00:00", "2025-01-01 00:00:00")),
        ("owner_property_map",
         "(owner_id,property_id,created_at,updated_at)",
         (9999, 300, "2025-01-01 00:00:00", "2025-01-01 00:00:00")),
        ("owner_property_map",
         "(owner_id,property_id,created_at,updated_at)",
         (400, 9999, "2025-01-01 00:00:00", "2025-01-01 00:00:00")),
        ("contracts",
         "(contract_id,vendor_id,title,start_date,end_date,created_at,updated_at)",
         (501, 9999, "Bad", "2025-01-01", None, "2025-01-01 00:00:00", "2025-01-01 00:00:00")),
    ]
)
def test_fk_negative_inserts_raise(cx, base_rows, table, cols, vals):
    with pytest.raises(sqlite3.IntegrityError):
        cx.execute(f"INSERT INTO {table} {cols} VALUES ({','.join('?'*len(vals))});", vals)

# -----------------------------
# 4) Delete guards / restrictions
# -----------------------------

def test_cannot_delete_pipeline_with_stages(cx, base_rows):
    with pytest.raises(sqlite3.IntegrityError):
        cx.execute("DELETE FROM pipelines WHERE pipeline_id=1;")

def test_cannot_delete_stage_with_ticket(cx, base_rows):
    insert_ticket_ok(cx, pipeline_id=1, stage_id=10)
    with pytest.raises(sqlite3.IntegrityError):
        cx.execute("DELETE FROM pipeline_stages WHERE stage_id=10;")

def test_cannot_delete_property_referenced_by_ticket(cx, base_rows):
    insert_ticket_ok(cx, pipeline_id=1, stage_id=10)
    with pytest.raises(sqlite3.IntegrityError):
        cx.execute("DELETE FROM properties WHERE property_id=300;")

def test_cannot_delete_property_referenced_by_owner_map(cx, base_rows):
    ts = "2025-01-01 00:00:00"
    cx.execute("""INSERT INTO owner_property_map(owner_id,property_id,created_at,updated_at)
                  VALUES(400,300,?,?);""", (ts, ts))
    with pytest.raises(sqlite3.IntegrityError):
        cx.execute("DELETE FROM properties WHERE property_id=300;")

def test_cannot_delete_owner_referenced_by_owner_map(cx, base_rows):
    ts = "2025-01-01 00:00:00"
    cx.execute("""INSERT INTO owner_property_map(owner_id,property_id,created_at,updated_at)
                  VALUES(400,300,?,?);""", (ts, ts))
    with pytest.raises(sqlite3.IntegrityError):
        cx.execute("DELETE FROM owner WHERE owner_id=400;")

    # explicit message from trg_vendor_has_contracts_bd
def test_cannot_delete_vendor_with_contracts_explicit_trigger_message(cx, base_rows):
    with pytest.raises(sqlite3.IntegrityError) as e:
        cx.execute("DELETE FROM vendors WHERE vendor_id=100;")
    assert "cannot delete vendor with contracts" in str(e.value).lower()

def test_cannot_delete_vendor_referenced_by_document_or_ticket(cx, base_rows):
    insert_document(cx, document_id=920, contract_id=500, vendor_id=100)
    insert_ticket_ok(cx, pipeline_id=1, stage_id=10, vendor_id=100)
    with pytest.raises(sqlite3.IntegrityError):
        cx.execute("DELETE FROM vendors WHERE vendor_id=100;")

# ------------------------------------
# 5) Positive flows for completeness
# ------------------------------------

def test_delete_stage_without_tickets_is_allowed(cx, base_rows):
    ts = "2025-01-01 00:00:00"
    cx.execute("""INSERT INTO pipeline_stages(stage_id,pipeline_id,stage_name,stage_order,created_at,updated_at)
                  VALUES(30,1,'Temp',2,?,?);""", (ts, ts))
    cx.execute("DELETE FROM pipeline_stages WHERE stage_id=30;")
    got = cx.execute("SELECT COUNT(*) FROM pipeline_stages WHERE stage_id=30;").fetchone()[0]
    assert got == 0

def test_delete_property_not_referenced_is_allowed(cx, base_rows):
    ts = "2025-01-01 00:00:00"
    cx.execute("""INSERT INTO properties(property_id,property_name,address,status,created_at,updated_at)
                  VALUES(301,'Spare','Addr','active',?,?);""", (ts, ts))
    cx.execute("DELETE FROM properties WHERE property_id=301;")
    got = cx.execute("SELECT COUNT(*) FROM properties WHERE property_id=301;").fetchone()[0]
    assert got == 0
