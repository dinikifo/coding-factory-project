# Clean header: import validators.py from the same folder (no try/except, no skips)
import importlib.util, pathlib
_here = pathlib.Path(__file__).parent.resolve()
_spec = importlib.util.spec_from_file_location('validators', _here / 'validators.py')
V = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(V)

# -*- coding: utf-8 -*-
"""
Negative/edge tests for validator layer.
- Mirrors your validators module (BaseValidator + per-entity schemas).
- Skips cleanly if validators are not importable (same pattern as your conftest).
"""
import pytest
import importlib, os, pathlib

modname = "./validators.py"
# guard against test-local shadowing


def _must_fail(validator_cls, data, *, partial=False, contains=None):
    v = validator_cls()
    with pytest.raises(V.ValidationError) as ei:
        if partial:
            v.validate_partial(data)
        else:
            v.validate_full(data)
    msg = str(ei.value)
    if contains:
        # allow either a single string or list of expected substrings
        if isinstance(contains, str):
            assert contains in msg
        else:
            for s in contains:
                assert s in msg


@pytest.mark.parametrize("validator_cls,required_keys,sample_ok", [
    (V.VendorsValidator,
     ["name", "vendor_type", "status", "phone", "email", "address", "created_at", "updated_at"],
     {"name":"Acme","vendor_type":"cleaning","status":"active","phone":"123",
      "email":"a@b.c","address":"X","created_at":"01.01.2024","updated_at":"02.01.2024"}),

    (V.ContractsValidator,
     ["vendor_id","contract_name","start_date","created_at","updated_at"],
     {"vendor_id":1,"contract_name":"SLA","start_date":"01.01.2024","end_date":"01.06.2024",
      "renewal_terms":"M2M","status":"active","created_at":"01.01.2024","updated_at":"01.01.2024"}),

    (V.PipelinesValidator,
     ["pipeline_name","description","created_at","updated_at"],
     {"pipeline_name":"Cleaning","description":"Turnovers","created_at":"01.01.2024","updated_at":"01.01.2024"}),

    (V.PipelineStagesValidator,
     ["pipeline_id","stage_name","created_at","updated_at"],
     {"pipeline_id":1,"stage_name":"Assigned","stage_order":1,"created_at":"01.01.2024","updated_at":"01.01.2024"}),

    (V.OpportunitiesTaskTicketsValidator,
     ["pipeline_id","stage_id","vendor_id","title","description","property_id","status",
      "due_date","created_at","updated_at"],
     {"pipeline_id":1,"stage_id":1,"vendor_id":1,"title":"Turnover","description":"Clean",
      "property_id":2,"status":"open","priority":"high","due_date":"01.02.2024",
      "created_at":"01.01.2024","updated_at":"01.01.2024"}),

    (V.PropertiesValidator,
     ["property_name","address","status","created_at","updated_at"],
     {"property_name":"Loft","address":"Somewhere","status":"active",
      "created_at":"01.01.2024","updated_at":"01.01.2024"}),

    (V.DocumentsValidator,
     ["vendor_id","contract_id","file_name","file_path","uploaded_at","updated_at"],
     {"vendor_id":1,"contract_id":1,"file_name":"contract.pdf","file_path":"/tmp/contract.pdf",
      "uploaded_at":"01.01.2024","updated_at":"01.01.2024"}),

    (V.CommunicationsValidator,
     ["vendor_id","date_sent","comm_type","subject","content","created_at","updated_at"],
     {"vendor_id":1,"date_sent":"01.01.2024","comm_type":"email","subject":"Hi","content":"Body",
      "user_id":"admin","followup_needed":"no","created_at":"01.01.2024","updated_at":"01.01.2024"}),

    (V.VendorContactsValidator,
     ["vendor_id","first_name","last_name","job_title","created_at","updated_at"],
     {"vendor_id":1,"first_name":"Jane","last_name":"Doe","job_title":"Rep",
      "phone":"123","email":"j@d","created_at":"01.01.2024","updated_at":"01.01.2024"}),

    (V.VendorScorecardValidator,
     ["vendor_id","period_start","period_end","created_at","updated_at"],
     {"vendor_id":1,"period_start":"01.01.2024","period_end":"31.01.2024",
      "quality_score":99.0,"on_time_delivery":100.0,"defect_rate":0.0,"comments":"OK",
      "created_at":"01.02.2024","updated_at":"01.02.2024"}),

    (V.OwnerValidator,
     ["first_name","last_name","phone","email","address","legal_id","created_at","updated_at"],
     {"first_name":"O","last_name":"W","phone":"x","email":"e","address":"A","legal_id":"L",
      "created_at":"01.01.2024","updated_at":"01.01.2024"}),

    (V.OwnerPropertyMapValidator,
     ["owner_id","property_id"],
     {"owner_id":1,"property_id":2,"created_at":"01.01.2024","updated_at":"01.01.2024"}),
])
def test_create_requires_required_fields(validator_cls, required_keys, sample_ok):
    # sanity: full payload passes
    v = validator_cls()
    v.validate_full(sample_ok)

    # remove each required key → must fail and mention the key
    for k in required_keys:
        bad = dict(sample_ok)
        bad.pop(k, None)
        _must_fail(validator_cls, bad, partial=False, contains="Missing required field")


@pytest.mark.parametrize("validator_cls,bad_payload,expect_fragments", [
    # Wrong types
    (V.ContractsValidator, {"vendor_id":"not-int","contract_name":123,"start_date":1,
                            "created_at":"01.01.2024","updated_at":"01.01.2024"},
     ["vendor_id must be an int","contract_name must be a string","start_date must be a date"]),
    # Bad date format
    (V.PropertiesValidator, {"property_name":"P","address":"A","status":"active",
                             "created_at":"2024-01-01","updated_at":"2024/01/02"},
     ["created_at must be in DD.MM.YYYY format","updated_at must be in DD.MM.YYYY format"]),
    # Unknown field
    (V.VendorsValidator, {"name":"X","vendor_type":"t","status":"s","phone":"p","email":"e",
                          "address":"a","created_at":"01.01.2024","updated_at":"01.01.2024",
                          "notacolumn":123},
     ["Unknown field: notacolumn"]),
    # Stage name must be string (schema said STR even if original DDL had INTEGER)
    (V.PipelineStagesValidator, {"pipeline_id":1,"stage_name":123,"created_at":"01.01.2024",
                                 "updated_at":"01.01.2024"},
     ["stage_name must be a string"]),
    # Description should be text (schema treats it STR)
    (V.OpportunitiesTaskTicketsValidator, {"pipeline_id":1,"stage_id":1,"vendor_id":1,
                                           "title":"t","description":999,"property_id":2,
                                           "status":"open","due_date":"01.02.2024",
                                           "created_at":"01.01.2024","updated_at":"01.01.2024"},
     ["description must be a string"]),
])
def test_type_and_format_errors(validator_cls, bad_payload, expect_fragments):
    _must_fail(validator_cls, bad_payload, partial=False, contains=expect_fragments)


def test_partial_update_checks_only_supplied_fields():
    v = V.VendorsValidator()
    # partial: OK to provide only one valid field
    v.validate_partial({"phone": "123"})
    # partial: providing a bad field must still be flagged
    with pytest.raises(V.ValidationError):
        v.validate_partial({"created_at": "2024-01-01"})  # wrong format
