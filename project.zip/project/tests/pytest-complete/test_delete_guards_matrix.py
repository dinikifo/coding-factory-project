import sqlite3, pytest

def seed_vendor(conn):
    cur = conn.execute(
        "INSERT INTO vendors(name,vendor_type,status,phone,email,address,created_at,updated_at) "
        "VALUES (?,?,?,?,?,?,?,?)",
        ("ACME","supplier","active","+30 210 0000000","acme@example.com","Somewhere 1","01.01.2024","01.01.2024")
    )
    return cur.lastrowid

def seed_pipeline(conn):
    cur = conn.execute(
        "INSERT INTO pipelines(pipeline_name,description,created_at,updated_at) "
        "VALUES (?,?,?,?)",
        ("Main","Default pipeline","01.01.2024","01.01.2024")
    )
    return cur.lastrowid

def seed_stage(conn, pipeline_id):
    cur = conn.execute(
        "INSERT INTO pipeline_stages(pipeline_id,stage_name,stage_order,created_at,updated_at) "
        "VALUES (?,?,?,?,?)",
        (pipeline_id,"Stage A",1,"01.01.2024","01.01.2024")
    )
    return cur.lastrowid

def seed_property(conn):
    cur = conn.execute(
        "INSERT INTO properties(property_name,address,status,created_at,updated_at) "
        "VALUES (?,?,?,?,?)",
        ("Villa Alpha","Address 1","active","01.01.2024","01.01.2024")
    )
    return cur.lastrowid

@pytest.mark.usefixtures("fresh_db")
def test_delete_guards_matrix(fresh_db):
    # Core seeds
    vendor_id = seed_vendor(fresh_db)
    pipeline_id = seed_pipeline(fresh_db)
    stage_id = seed_stage(fresh_db, pipeline_id)

    # (A) pipelines -> stages (fk_pipelines_has_children_bd)
    with pytest.raises(sqlite3.IntegrityError):
        fresh_db.execute("DELETE FROM pipelines WHERE pipeline_id=?", (pipeline_id,))

    # (B) pipeline_stages -> opportunities_task_tickets (fk_pipeline_stages_has_opp_bd)
    property_id = seed_property(fresh_db)
    # create a ticket referencing the stage & pipeline & vendor & property
    fresh_db.execute(
        "INSERT INTO opportunities_task_tickets(pipeline_id,stage_id,vendor_id,title,description,property_id,status,priority,due_date,created_at,updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (pipeline_id,stage_id,vendor_id,"Fix leak","desc",property_id,"open","high","01.01.2024","01.01.2024","01.01.2024")
    )
    with pytest.raises(sqlite3.IntegrityError):
        fresh_db.execute("DELETE FROM pipeline_stages WHERE stage_id=?", (stage_id,))

    # (C) properties -> owner_property_map / opportunities_task_tickets (fk_properties_has_children_bd)
    # Already referenced by the ticket, so deleting property should fail.
    with pytest.raises(sqlite3.IntegrityError):
        fresh_db.execute("DELETE FROM properties WHERE property_id=?", (property_id,))

    # (D) owner <- owner_property_map (fk_owner_has_map_bd)
    # create owner and map to property
    owner_id = fresh_db.execute(
        "INSERT INTO owner(first_name,last_name,phone,email,address,legal_id,created_at,updated_at) "
        "VALUES (?,?,?,?,?,?,?,?)",
        ("Ann","Owner","+30 210 1111111","ann@example.com","Owner Addr","LGL123","01.01.2024","01.01.2024")
    ).lastrowid
    fresh_db.execute(
        "INSERT INTO owner_property_map(owner_id,property_id,created_at,updated_at) "
        "VALUES (?,?,?,?)",
        (owner_id, property_id, "01.01.2024", "01.01.2024")
    )
    with pytest.raises(sqlite3.IntegrityError):
        fresh_db.execute("DELETE FROM owner WHERE owner_id=?", (owner_id,))
