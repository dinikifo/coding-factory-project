import sqlite3, pathlib, os, pytest

ROOT = pathlib.Path(__file__).resolve().parent
SCHEMA_PATH = pathlib.Path(os.getenv("SCHEMA_PATH", str(ROOT / "schema.sql")))

def _load_schema(conn):
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        sql = f.read()
        # Normalize whitespace & line endings (optional but helps portability)
        sql = sql.replace("\r\n", "\n")
        # SQLite doesn't support OR REPLACE for CREATE TRIGGER/VIEW
        sql = sql.replace("CREATE OR REPLACE TRIGGER", "CREATE TRIGGER")
        sql = sql.replace("CREATE OR REPLACE VIEW", "CREATE VIEW")
        # Some dialects embed IF NOT EXISTS in places SQLite doesn't like for triggers/views.
        # Keep CREATE TABLE IF NOT EXISTS but avoid it on triggers.
        sql = sql.replace("CREATE TRIGGER IF NOT EXISTS", "CREATE TRIGGER")
        conn.executescript(sql)
    conn.commit()

@pytest.fixture(scope="function")
def fresh_db():
    """Compatibility fixture used by legacy tests."""
    conn = sqlite3.connect(":memory:")
    conn.execute("PRAGMA foreign_keys = ON;")
    _load_schema(conn)
    yield conn
    conn.close()

@pytest.fixture(scope="function")
def cx():
    """Fixture used by the new integrity tests."""
    conn = sqlite3.connect(":memory:")
    conn.execute("PRAGMA foreign_keys = ON;")
    _load_schema(conn)
    yield conn
    conn.close()

@pytest.fixture()
def base_rows(cx):
    """Seed canonical reference rows for integrity tests."""
    ts = "2025-01-01 00:00:00"

    # Vendors
    cx.execute("""INSERT INTO vendors(vendor_id,name,vendor_type,status,phone,email,address,created_at,updated_at)
                  VALUES(100,'Vendor X','supplier','active',NULL,NULL,NULL,?,?);""", (ts, ts))
    cx.execute("""INSERT INTO vendors(vendor_id,name,vendor_type,status,phone,email,address,created_at,updated_at)
                  VALUES(200,'Vendor Y','supplier','active',NULL,NULL,NULL,?,?);""", (ts, ts))

    # Pipelines
    cx.execute("""INSERT INTO pipelines(pipeline_id,pipeline_name,description,created_at,updated_at)
                  VALUES(1,'Pipe A',NULL,?,?);""", (ts, ts))
    cx.execute("""INSERT INTO pipelines(pipeline_id,pipeline_name,description,created_at,updated_at)
                  VALUES(2,'Pipe B',NULL,?,?);""", (ts, ts))

    # Stages (10 -> pipeline 1, 20 -> pipeline 2)
    cx.execute("""INSERT INTO pipeline_stages(stage_id,pipeline_id,stage_name,stage_order,created_at,updated_at)
                  VALUES(10,1,'Stage A1',1,?,?);""", (ts, ts))
    cx.execute("""INSERT INTO pipeline_stages(stage_id,pipeline_id,stage_name,stage_order,created_at,updated_at)
                  VALUES(20,2,'Stage B1',1,?,?);""", (ts, ts))

    # Properties
    cx.execute("""INSERT INTO properties(property_id,property_name,address,status,created_at,updated_at)
                  VALUES(300,'Property One','Addr','active',?,?);""", (ts, ts))

    # Owner
    cx.execute("""INSERT INTO owner(owner_id,first_name,last_name,phone,email,address,legal_id,created_at,updated_at)
                  VALUES(400,'O','One',NULL,NULL,NULL,NULL,?,?);""", (ts, ts))

    # Contract (vendor 100)
    cx.execute("""INSERT INTO contracts(contract_id,vendor_id,title,start_date,end_date,created_at,updated_at)
                  VALUES(500,100,'Contract X','2025-01-01',NULL,?,?);""", (ts, ts))

    cx.commit()
    return dict(ts=ts)
