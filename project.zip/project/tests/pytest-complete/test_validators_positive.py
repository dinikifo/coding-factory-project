# Clean header: import validators.py from the same folder (no try/except, no skips)
import importlib.util, pathlib
_here = pathlib.Path(__file__).parent.resolve()
_spec = importlib.util.spec_from_file_location('validators', _here / 'validators.py')
V = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(V)

# -*- coding: utf-8 -*-
import importlib, os, pathlib, pytest
modname = "./validators"


def _ok(vcls, payload_full, payload_partial):
    v = vcls()
    v.validate_full(payload_full)
    v.validate_partial(payload_partial)

def test_vendors_positive():
    _ok(V.VendorsValidator,
        {"name":"Acme","vendor_type":"cleaning","status":"active","phone":"123",
         "email":"a@b.c","address":"X","created_at":"01.01.2024","updated_at":"02.01.2024"},
        {"phone":"321"})

def test_contracts_positive():
    _ok(V.ContractsValidator,
        {"vendor_id":1,"contract_name":"SLA","start_date":"01.01.2024","end_date":"01.06.2024",
         "renewal_terms":"M2M","status":"active","created_at":"01.01.2024","updated_at":"01.01.2024"},
        {"status":"inactive"})

def test_pipeline_and_stage_positive():
    _ok(V.PipelinesValidator,
        {"pipeline_name":"Cleaning","description":"Turnovers","created_at":"01.01.2024","updated_at":"01.01.2024"},
        {"description":"Deep cleans"})
    _ok(V.PipelineStagesValidator,
        {"pipeline_id":1,"stage_name":"Assigned","stage_order":1,"created_at":"01.01.2024","updated_at":"01.01.2024"},
        {"stage_order":2})

def test_opportunity_positive():
    _ok(V.OpportunitiesTaskTicketsValidator,
        {"pipeline_id":1,"stage_id":1,"vendor_id":1,"title":"Turnover","description":"Clean",
         "property_id":2,"status":"open","priority":"high","due_date":"01.02.2024",
         "created_at":"01.01.2024","updated_at":"01.01.2024"},
        {"status":"closed"})

def test_documents_positive():
    _ok(V.DocumentsValidator,
        {"vendor_id":1,"contract_id":1,"file_name":"contract.pdf","file_path":"/tmp/contract.pdf",
         "uploaded_at":"01.01.2024","updated_at":"01.01.2024"},
        {"file_name":"v2.pdf"})
