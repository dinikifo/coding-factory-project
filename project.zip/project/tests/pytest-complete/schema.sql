-- Canonical SQLite schema for the CRM tests (single source of truth)
PRAGMA foreign_keys = ON;

--------------------------
-- Core reference tables --
--------------------------
CREATE TABLE IF NOT EXISTS vendors (
    vendor_id     INTEGER PRIMARY KEY,
    name          TEXT NOT NULL,
    vendor_type   TEXT NOT NULL,
    status        TEXT NOT NULL,
    phone         TEXT,
    email         TEXT,
    address       TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pipelines (
    pipeline_id   INTEGER PRIMARY KEY,
    pipeline_name TEXT NOT NULL,
    description   TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pipeline_stages (
    stage_id      INTEGER PRIMARY KEY,
    pipeline_id   INTEGER NOT NULL,
    stage_name    TEXT NOT NULL,
    stage_order   INTEGER NOT NULL,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL,
    FOREIGN KEY (pipeline_id) REFERENCES pipelines(pipeline_id) ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS properties (
    property_id   INTEGER PRIMARY KEY,
    property_name TEXT NOT NULL,
    address       TEXT NOT NULL,
    status        TEXT NOT NULL,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS owner (
    owner_id      INTEGER PRIMARY KEY,
    first_name    TEXT NOT NULL,
    last_name     TEXT NOT NULL,
    phone         TEXT,
    email         TEXT,
    address       TEXT,
    legal_id      TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS owner_property_map (
    owner_id     INTEGER NOT NULL,
    property_id  INTEGER NOT NULL,
    created_at   TEXT NOT NULL,
    updated_at   TEXT NOT NULL,
    PRIMARY KEY (owner_id, property_id),
    FOREIGN KEY (owner_id)    REFERENCES owner(owner_id)         ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE RESTRICT ON UPDATE CASCADE
);

---------------------
-- Contracts & docs --
---------------------
CREATE TABLE IF NOT EXISTS contracts (
    contract_id   INTEGER PRIMARY KEY,
    vendor_id     INTEGER NOT NULL,
    title         TEXT NOT NULL,
    start_date    TEXT NOT NULL,
    end_date      TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL,
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id) ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS documents (
    document_id   INTEGER PRIMARY KEY,
    contract_id   INTEGER NOT NULL,
    vendor_id     INTEGER NOT NULL,
    file_name     TEXT NOT NULL,
    mime_type     TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL,
    FOREIGN KEY (contract_id) REFERENCES contracts(contract_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (vendor_id)   REFERENCES vendors(vendor_id)     ON DELETE RESTRICT ON UPDATE CASCADE
);

-- Invariant: document.vendor_id must match the contract.vendor_id
CREATE TRIGGER IF NOT EXISTS trg_documents_vendor_matches_contract
BEFORE INSERT ON documents
FOR EACH ROW
BEGIN
    SELECT
        CASE
            WHEN (SELECT vendor_id FROM contracts WHERE contract_id = NEW.contract_id) != NEW.vendor_id
            THEN RAISE(ABORT, 'document vendor mismatch with contract')
        END;
END;

CREATE TRIGGER IF NOT EXISTS trg_documents_vendor_matches_contract_update
BEFORE UPDATE OF contract_id, vendor_id ON documents
FOR EACH ROW
BEGIN
    SELECT
        CASE
            WHEN (SELECT vendor_id FROM contracts WHERE contract_id = NEW.contract_id) != NEW.vendor_id
            THEN RAISE(ABORT, 'document vendor mismatch with contract')
        END;
END;

---------------------------------------------
-- Opportunities / tasks / tickets (tickets)
---------------------------------------------
CREATE TABLE IF NOT EXISTS opportunities_task_tickets (
    ticket_id     INTEGER PRIMARY KEY,
    pipeline_id   INTEGER NOT NULL,
    stage_id      INTEGER NOT NULL,
    vendor_id     INTEGER NOT NULL,
    property_id   INTEGER NOT NULL,
    title         TEXT NOT NULL,
    description   TEXT NOT NULL,
    status        TEXT NOT NULL,   -- e.g. open/closed
    priority      TEXT,            -- e.g. low/medium/high
    due_date      TEXT NOT NULL,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL,
    FOREIGN KEY (pipeline_id) REFERENCES pipelines(pipeline_id)           ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (stage_id)    REFERENCES pipeline_stages(stage_id)        ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (vendor_id)   REFERENCES vendors(vendor_id)               ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (property_id) REFERENCES properties(property_id)          ON DELETE RESTRICT ON UPDATE CASCADE
);

-- Invariant: stage must belong to pipeline
CREATE TRIGGER IF NOT EXISTS trg_ticket_stage_in_pipeline
BEFORE INSERT ON opportunities_task_tickets
FOR EACH ROW
BEGIN
    SELECT
        CASE
            WHEN NOT EXISTS (
                SELECT 1 FROM pipeline_stages s
                WHERE s.stage_id = NEW.stage_id AND s.pipeline_id = NEW.pipeline_id
            )
            THEN RAISE(ABORT, 'stage not in pipeline')
        END;
END;

CREATE TRIGGER IF NOT EXISTS trg_ticket_stage_in_pipeline_update
BEFORE UPDATE OF stage_id, pipeline_id ON opportunities_task_tickets
FOR EACH ROW
BEGIN
    SELECT
        CASE
            WHEN NOT EXISTS (
                SELECT 1 FROM pipeline_stages s
                WHERE s.stage_id = NEW.stage_id AND s.pipeline_id = NEW.pipeline_id
            )
            THEN RAISE(ABORT, 'stage not in pipeline')
        END;
END;

--------------------------------------------------
-- Delete-guard semantics (mostly via FK RESTRICT)
--------------------------------------------------
-- Pipelines with children stages cannot be deleted (FK RESTRICT above).
-- Stages with referencing tickets cannot be deleted (FK RESTRICT above).
-- Properties referenced by tickets or owner map cannot be deleted (FK RESTRICT above).
-- Owners referenced by map cannot be deleted (FK RESTRICT above).
-- Vendors referenced by contracts/tickets/documents cannot be deleted (FK RESTRICT above).

-- Optional explicit sanity trigger for vendor delete when contracts exist (clear error message)
CREATE TRIGGER IF NOT EXISTS trg_vendor_has_contracts_bd
BEFORE DELETE ON vendors
FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM contracts c WHERE c.vendor_id = OLD.vendor_id)
BEGIN
    SELECT RAISE(ABORT, 'cannot delete vendor with contracts');
END;
