# -*- coding: utf-8 -*-
# Verbose black-box tests against the HTTPS JWT service on https://localhost:8000
# HARD-CODED config & data. No external parameters required.

import sys
import json
from datetime import datetime

import pytest
import requests
import urllib3

# ----------------------------- HARD-CODED CONFIG -----------------------------

BASE_URL = "https://localhost:8000"
TIMEOUT = 10  # seconds

ADMIN_USER = "admin"
ADMIN_PW   = "secret"

USER_USER  = "jane"
USER_PW    = "1234"


from pathlib import Path
import certifi
import os

# --- TLS trust: use the CA bundled with this test file ---
HERE = Path(__file__).resolve().parent
CA_BUNDLE = "../certs/rootCA.pem"


# Use this in all requests calls
TIMEOUT = 10  # keep your previous value if you already have one
REQUESTS_DEFAULTS = dict(timeout=TIMEOUT, verify=str(CA_BUNDLE))

print(f"TLS: using CA bundle → {CA_BUNDLE}")



# ----------------------------- PRINT HELPERS ---------------------------------

def _flush(msg: str) -> None:
    print(msg)
    sys.stdout.flush()

def banner(title: str) -> None:
    line = "═" * max(20, len(title) + 4)
    _flush(f"\n{line}\n  {title}\n{line}")

def stage(msg: str) -> None:
    _flush(f"• {msg}")

def success(msg: str) -> None:
    _flush(f"  ✅ {msg}")

def fail(msg: str) -> None:
    _flush(f"  ❌ {msg}")

def ddmmyyyy() -> str:
    return datetime.now().strftime("%d.%m.%Y")

def show_response(r: requests.Response, label: str = "") -> None:
    try:
        body = r.json()
        pretty = json.dumps(body, indent=2, ensure_ascii=False)
    except Exception:
        pretty = r.text[:500]
    prefix = f"{label}: " if label else ""
    _flush(f"    ↳ {prefix}HTTP {r.status_code}\n{pretty}\n")

# ----------------------------- CLIENT ----------------------------------------

class Client:
    """
    Cookie-based auth client (matches service behavior):
      - POST /login with JSON {username,password}
      - Reads X-CSRF-Token cookie; sends it back as header for write methods
      - Uses access_token cookie automatically (requests.Session)
    """
    def __init__(self, base: str, username: str, password: str):
        self.base = base.rstrip("/")
        self.s = requests.Session()
        self.csrf = None
        self.write_headers = {}
        self.read_headers = {}
        stage(f"Logging in as '{username}'")
        r = self.s.post(f"{self.base}/login",
                        json={"username": username, "password": password},
                        **REQUESTS_DEFAULTS)
        show_response(r, "login")
        assert r.status_code == 200, f"LOGIN FAILED ({r.status_code})"
        self.csrf = r.cookies.get("X-CSRF-Token") or self.s.cookies.get("X-CSRF-Token")
        assert self.csrf, "LOGIN OK but no CSRF cookie found"
        self.write_headers = {"X-CSRF-Token": self.csrf, "Content-Type": "application/json"}
        self.read_headers = {}
        success(f"Logged in as '{username}'")

    def refresh(self):
        stage("Refreshing access token using refresh cookie")
        r = self.s.post(f"{self.base}/refresh", **REQUESTS_DEFAULTS)
        show_response(r, "refresh")
        return r

    def me(self):
        stage("Calling /me")
        r = self.s.get(f"{self.base}/me", headers=self.read_headers, **REQUESTS_DEFAULTS)
        show_response(r, "me")
        return r

    def logout(self):
        stage("Logging out")
        r = self.s.post(f"{self.base}/logout", headers=self.write_headers, **REQUESTS_DEFAULTS)
        show_response(r, "logout")
        return r

    # ----- Generic CRUD (cookie auth + CSRF for writes) -----
    def create(self, entity: str, payload: dict):
        stage(f"Creating {entity[:-1]} via POST /{entity}/")
        r = self.s.post(f"{self.base}/{entity}/", json=payload, headers=self.write_headers, **REQUESTS_DEFAULTS)
        show_response(r, f"{entity}.create")
        return r

    def get_range(self, entity: str, lo, hi):
        stage(f"Reading {entity} range [{lo}, {hi}] via GET /{entity}/{lo}/{hi}/")
        r = self.s.get(f"{self.base}/{entity}/{lo}/{hi}/", headers=self.read_headers, **REQUESTS_DEFAULTS)
        show_response(r, f"{entity}.get_range")
        return r

    def update(self, entity: str, payload: dict):
        stage(f"Updating {entity[:-1]} via PUT /{entity}/")
        r = self.s.put(f"{self.base}/{entity}/", json=payload, headers=self.write_headers, **REQUESTS_DEFAULTS)
        show_response(r, f"{entity}.update")
        return r

    def delete(self, entity: str, payload: dict):
        stage(f"Deleting {entity[:-1]} via DELETE /{entity}/")
        r = self.s.delete(f"{self.base}/{entity}/", json=payload, headers=self.write_headers, **REQUESTS_DEFAULTS)
        show_response(r, f"{entity}.delete")
        return r

# ----------------------------- FIXTURES --------------------------------------

@pytest.fixture(scope="module")
def admin_client():
    banner("SETUP: Admin client")
    return Client(BASE_URL, ADMIN_USER, ADMIN_PW)

@pytest.fixture(scope="module")
def user_client():
    banner("SETUP: User client")
    return Client(BASE_URL, USER_USER, USER_PW)

# ----------------------------- HARD-CODED PAYLOADS ---------------------------

def seed_vendor():
    ts = ddmmyyyy()
    return {
        "name":        "ACME_Test_Vendor",
        "vendor_type": "Maintenance",
        "status":      "Active",
        "phone":       "+1-555-0100",
        "email":       "acme@example.com",
        "address":     "101 Test Street",
        "created_at":  ts,
        "updated_at":  ts,
    }

def seed_vendor_update(vendor_id: int):
    ts = ddmmyyyy()
    return {
        "vendor_id":   vendor_id,
        "status":      "Inactive",
        "updated_at":  ts,
    }

# ----------------------------- TESTS: AUTH -----------------------------------

def test_login_admin_and_user(admin_client, user_client):
    banner("TEST: Login flow for admin and user")
    try:
        admin_cookies = admin_client.s.cookies
        user_cookies = user_client.s.cookies
        for jar, who in [(admin_cookies, "admin"), (user_cookies, "user")]:
            stage(f"Checking cookies for {who}")
            assert "access_token" in jar, f"{who}: missing access_token cookie"
            assert "refresh_token" in jar, f"{who}: missing refresh_token cookie"
            assert "X-CSRF-Token" in jar,  f"{who}: missing CSRF cookie"
        success("Login cookies present for both admin and user")
    except AssertionError as e:
        fail(str(e))
        raise

def test_me_endpoint_returns_identity(admin_client, user_client):
    banner("TEST: /me returns correct identity and role")
    try:
        r1 = admin_client.me()
        assert r1.status_code == 200
        assert r1.json().get("user", {}).get("username") == ADMIN_USER
        assert r1.json().get("user", {}).get("role") == "admin"
        success("Admin identity & role confirmed")

        r2 = user_client.me()
        assert r2.status_code == 200
        assert r2.json().get("user", {}).get("username") == USER_USER
        assert r2.json().get("user", {}).get("role") == "user"
        success("User identity & role confirmed")
    except AssertionError as e:
        fail(str(e))
        raise

def test_refresh_sets_new_access_cookie(admin_client):
    banner("TEST: /refresh rotates access token")
    try:
        r = admin_client.refresh()
        assert r.status_code == 200
        assert "access_token" in admin_client.s.cookies
        success("Refresh succeeded and access_token cookie present")
    except AssertionError as e:
        fail(str(e))
        raise

def test_csrf_required_on_write_without_header_fails():
    banner("TEST: CSRF enforcement on write endpoints")
    try:
        s = requests.Session()
        stage("Login (without storing CSRF header)")
        r_login = s.post(f"{BASE_URL}/login",
                         json={"username": ADMIN_USER, "password": ADMIN_PW},
                         **REQUESTS_DEFAULTS)
        show_response(r_login, "login(no-csrf-client)")
        assert r_login.status_code == 200

        stage("Attempt write without X-CSRF-Token header")
        r_logout = s.post(f"{BASE_URL}/logout", **REQUESTS_DEFAULTS)
        show_response(r_logout, "logout(missing-csrf)")
        assert r_logout.status_code in (401, 403), f"Expected CSRF/auth failure, got {r_logout.status_code}"
        success("Write without CSRF was correctly blocked")
    except AssertionError as e:
        fail(str(e))
        raise

# ----------------------------- TESTS: CRUD (vendors) -------------------------

def test_vendor_crud_admin_success_and_user_forbidden(admin_client, user_client):
    banner("TEST: Vendors CRUD (admin success, user forbidden)")
    vendor_id = None
    try:
        # Create
        r_create = admin_client.create("vendors", seed_vendor())
        assert r_create.status_code in (200, 201), r_create.text
        body = r_create.json()
        assert body.get("insertStatus") is True
        assert "vendor_id" in body
        vendor_id = body["vendor_id"]
        success(f"Created vendor with id={vendor_id}")

        # Read (admin)
        r_read_admin = admin_client.get_range("vendors", vendor_id, vendor_id)
        assert r_read_admin.status_code == 200
        data = r_read_admin.json().get("data", [])
        assert isinstance(data, list) and len(data) == 1
        assert data[0]["vendor_id"] == vendor_id
        success("Admin read-back returned the created vendor")

        # Read (user)
        r_read_user = user_client.get_range("vendors", vendor_id, vendor_id)
        assert r_read_user.status_code == 200
        success("User read access allowed")

        # Update (user forbidden)
        r_update_user = user_client.update("vendors", seed_vendor_update(vendor_id))
        assert r_update_user.status_code == 403, f"user update should be forbidden, got {r_update_user.status_code}"
        success("User update correctly forbidden")

        # Update (admin ok)
        r_update_admin = admin_client.update("vendors", seed_vendor_update(vendor_id))
        assert r_update_admin.status_code == 200
        assert r_update_admin.json().get("updateStatus") is True
        success("Admin update succeeded")

        # Delete (user forbidden)
        r_delete_user = user_client.delete("vendors", {"vendor_id": vendor_id})
        assert r_delete_user.status_code == 403, f"user delete should be forbidden, got {r_delete_user.status_code}"
        success("User delete correctly forbidden")

        # Delete (admin ok)
        r_delete_admin = admin_client.delete("vendors", {"vendor_id": vendor_id})
        assert r_delete_admin.status_code == 200
        assert r_delete_admin.json().get("deleteStatus") is True
        success("Admin delete succeeded")

    except AssertionError as e:
        fail(str(e))
        # Best-effort cleanup if create succeeded
        if vendor_id is not None:
            try:
                admin_client.delete("vendors", {"vendor_id": vendor_id})
            except Exception:
                pass
        raise

def test_logout_admin(admin_client):
    banner("TEST: Logout")
    try:
        r = admin_client.logout()
        assert r.status_code == 200
        success("Logout completed")
    except AssertionError as e:
        fail(str(e))
        raise

# ----------------------------- SELF-RUNNING ENTRY ----------------------------

if __name__ == "__main__":
    banner("BLACK-BOX TESTS: HTTPS JWT SERVICE @ https://localhost:8000")
    _flush("Running with verbose, uncaptured output. Sit back and watch each step.\n")
    # Force pytest to show print() output without needing CLI flags.
    sys.exit(pytest.main(["-s", "-q", __file__]))
