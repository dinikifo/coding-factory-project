# app.py  (class-heavy service; Bottle + SQLite)
from __future__ import annotations

import ssl
from wsgiref.simple_server import make_server, WSGIServer, WSGIRequestHandler

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from functools import wraps
from typing import Any, Dict, Sequence

from bottle import Bottle, request, response, run
import jwt

import json, os, bcrypt,sys

HTTPS_HOST = "0.0.0.0"
HTTPS_PORT = 8000

# Defaults (can be overridden by env)
CERT_FILE = "./certs/cert.pem"
KEY_FILE  = "./certs/key.pem"

def serve_https(app):
    httpd = make_server(HTTPS_HOST, HTTPS_PORT, app,
                        server_class=WSGIServer,
                        handler_class=WSGIRequestHandler)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(certfile=CERT_FILE, keyfile=KEY_FILE)
    httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
    print(f"HTTPS on https://{HTTPS_HOST}:{HTTPS_PORT} (cert={CERT_FILE})")
    httpd.serve_forever()


# --- (optional) HTTP→HTTPS redirector at 80 ---
"""
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlsplit, quote

HTTP_PORT = 80  # require CAP_NET_BIND_SERVICE or admin rights

class RedirectToHTTPS(BaseHTTPRequestHandler):
    def do_GET(self): self.redirect()
    def do_HEAD(self): self.redirect()
    def do_POST(self): self.redirect()
    def do_PUT(self): self.redirect()
    def do_DELETE(self): self.redirect()
    def do_PATCH(self): self.redirect()
    def do_OPTIONS(self): self.redirect()

    def redirect(self):
        host = self.headers.get("Host", "")
        if ":" in host:  # πετάμε την πόρτα που έστειλε ο client
            host = host.split(":", 1)[0]
        # ασφαλής ανακατασκευή path+query
        parsed = urlsplit(self.path)
        path = "/".join(quote(p, safe="") for p in parsed.path.split("/"))
        q = f"?{parsed.query}" if parsed.query else ""
        location = f"https://{host}:{HTTPS_PORT}{path}{q}"

        self.send_response(308)
        self.send_header("Location", location)
        # HSTS μόνο αν είσαι σίγουρος για το hostname
        # self.send_header("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        self.end_headers()

def serve_http_redirect():
    srv = HTTPServer(("0.0.0.0", HTTP_PORT), RedirectToHTTPS)
    print(f"HTTP redirector on http://0.0.0.0:{HTTP_PORT} -> https://<host>:{HTTPS_PORT}")
    srv.serve_forever()

"""

# -----------------------------------------------------------------------------
# Auth setup (same users/roles as your current app)
# -----------------------------------------------------------------------------
"""
SECRET_KEY = "your_secret_key_here"
revoked_tokens = set()

users = {
    "admin": {"password": "secret", "role": "admin"},
    "jane":  {"password": "1234",  "role": "user"},
}
"""

#users={}
revoked_tokens = set()
#SECRET_KEY = "your_secret_key_here"

def init_SECRET_KEY_USERS(path):
    global users
    global SECRET_KEY
    try:
        with open(path) as user_file:
            fdata = user_file.read()
            #print(fdata)
            jdata = json.loads(fdata)
            SECRET_KEY=jdata['SECRET_KEY']
            users={}
            for key in jdata:
                if key!='SECRET_KEY':
                    users[key]=jdata[key]
    except:                
        print(f"Failed to load users/secret file: {e}")
        sys.exit(1)

init_SECRET_KEY_USERS('secret_users.json')


def generate_refresh_token(username: str, role: str) -> str:
    payload = {"username": username, "role": role,
               "exp": datetime.now(timezone.utc) + timedelta(days=7)}
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

def generate_csrf() -> str:
    import secrets
    return secrets.token_urlsafe(32)

def generate_token(username: str, role: str) -> str:
    payload = {"username": username, "role": role,
               "exp": datetime.now(timezone.utc) + timedelta(hours=1)}
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

def decode_token(token: str):
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

def auth_required(fn):
    @wraps(fn)
    def _wrap(*a, **kw):
        token = None
        h = request.get_header("Authorization") or ""
        if h.startswith("Bearer "):
            token = h.split(" ", 1)[1]
        else:
            token = request.get_cookie("access_token")
        if not token:
            response.status = 401
            return {"error": "Missing credentials"}
        if token in revoked_tokens:
            response.status = 401
            return {"error": "Token has been revoked"}
        payload = decode_token(token)
        if not payload:
            response.status = 401
            return {"error": "Invalid or expired token"}
        request.environ["user"] = payload["username"]
        request.environ["role"] = payload["role"]
        return fn(*a, **kw)
    return _wrap

def admin_only(fn):
    @wraps(fn)
    def _wrap(*a, **kw):
        if request.environ.get("role") != "admin":
            response.status = 403
            return {"error": "Admin privileges required"}
        return fn(*a, **kw)
    return _wrap

# NEW: centralized DB error mapping for all routes
def handle_db_errors(fn):
    @wraps(fn)
    def _wrap(*a, **kw):
        try:
            return fn(*a, **kw)
        except sqlite3.IntegrityError as e:
            # FK / unique / CHECK violations
            response.status = 409  # or 422 if you prefer
            return {"error": "DB constraint violation", "detail": str(e)}
        except sqlite3.OperationalError as e:
            response.status = 400
            return {"error": "DB operational error", "detail": str(e)}
        except Exception:
            response.status = 500
            return {"error": "Internal server error"}
    return _wrap

# -----------------------------------------------------------------------------
# App & static pages (unchanged)
# -----------------------------------------------------------------------------
app = Bottle()

@app.get('/openapi.yaml')
def serve_common():
    response.content_type = 'application/yaml'
    with open('./openapi-3.1.yaml', 'r', encoding='utf-8') as f:
        return f.read()

@app.get('/app.js')
def serve_common():
    response.content_type = 'application/javascript'
    with open('./app.js', 'r', encoding='utf-8') as f:
        return f.read()

for page in [
    "pipeline-map.html", 
    "index.html", 
    "create-update.html",
    #"read.html", 
    #"update.html",
     #"delete.html",
     "docs.html"
]:
    @app.get(f'/{page}')  # type: ignore[misc]
    def _serve(page=page):
        with open(f'./{page}', 'r', encoding='utf-8') as f:
            return f.readlines()

@app.post('/login')
def login():
    data = request.json or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    user = users.get(username)

    if not user:
        response.status = 401
        return {"error": "Invalid credentials"}

    stored = user.get("password")
    # stored may be str (from json). bcrypt wants bytes.
    if not stored:
        response.status = 401
        return {"error": "Invalid credentials"}

    # Normalize to bytes
    if isinstance(stored, str):
        stored_bytes = stored.encode("utf-8")
    else:
        stored_bytes = stored

    if not bcrypt.checkpw(password.encode("utf-8"), stored_bytes):
        response.status = 401
        return {"error": "Invalid credentials"}

    access = generate_token(username, user["role"])
    refresh = generate_refresh_token(username, user["role"])
    secure_flag = (request.urlparts.scheme == "https")
    response.set_cookie("access_token", access, httponly=True, path="/", samesite="lax", secure=secure_flag)
    response.set_cookie("refresh_token", refresh, httponly=True, path="/", samesite="lax", secure=secure_flag)
    csrf = generate_csrf()
    response.set_cookie("X-CSRF-Token", csrf, httponly=False, path="/", samesite="lax", secure=secure_flag)
    return {"ok": True}

def csrf_protect(fn):
    @wraps(fn)
    def _wrap(*a, **kw):
        # Enforce only for write methods (logout is POST)
        if request.method in ('POST', 'PUT', 'PATCH', 'DELETE'):
            client = request.get_header('X-CSRF-Token')
            cookie = request.get_cookie('X-CSRF-Token')
            if not client or not cookie or client != cookie:
                response.status = 403
                return {"error": "CSRF check failed"}
        return fn(*a, **kw)
    return _wrap

@app.post('/logout')
@csrf_protect
def logout():
    for name in ('access_token', 'refresh_token', 'X-CSRF-Token'):
        response.delete_cookie(name, path='/')
    return {"ok": True}

def _run_validation(validator_cls, data: Dict[str, Any], *, partial: bool):
    try:
        v = validator_cls()
        (v.validate_partial if partial else v.validate_full)(data)
    except ValidationError as e:
        response.status = 400
        return {"error": str(e)}
    return None

# -----------------------------------------------------------------------------
# Validators (your existing module)
# -----------------------------------------------------------------------------
from validators import (
    VendorsValidator, VendorContactsValidator, VendorScorecardValidator,
    ContractsValidator, PipelinesValidator, PipelineStagesValidator,
    OpportunitiesTaskTicketsValidator, PropertiesValidator, DocumentsValidator,
    CommunicationsValidator, OwnerValidator, OwnerPropertyMapValidator,
    ValidationError,
)

def _run_validation(validator_cls, data: Dict[str, Any], *, partial: bool):
    try:
        v = validator_cls()
        (v.validate_partial if partial else v.validate_full)(data)
    except ValidationError as e:
        response.status = 400
        return {"error": str(e)}
    return None
    
# entity → (validator_cls, pk_field)
VALIDATORS: Dict[str, tuple[Any, str]] = {
    "vendors": (VendorsValidator, "vendor_id"),
    "vendor_contacts": (VendorContactsValidator, "contact_id"),
    "vendor_scorecard": (VendorScorecardValidator, "scorecard_id"),
    "contracts": (ContractsValidator, "contract_id"),
    "pipelines": (PipelinesValidator, "pipeline_id"),
    "pipeline_stages": (PipelineStagesValidator, "stage_id"),
    # Note: route uses singular, table is plural in DB; keep existing behavior. :contentReference[oaicite:2]{index=2}
    "opportunities_task_ticket": (OpportunitiesTaskTicketsValidator, "opportunity_id"),
    "properties": (PropertiesValidator, "property_id"),
    "documents": (DocumentsValidator, "document_id"),
    "communications": (CommunicationsValidator, "communication_id"),
    "owner": (OwnerValidator, "owner_id"),
    "owner_property_map": (OwnerPropertyMapValidator, "map_id"),
}

def _current_ts() -> str:
    return datetime.now(timezone.utc).strftime("%d.%m.%Y")

# -----------------------------------------------------------------------------
# Database layer (FKs ON + transaction)
# -----------------------------------------------------------------------------
class CRMDatabase:
    def __init__(self, db_path: str):
        self.db_path = db_path

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.db_path, detect_types=sqlite3.PARSE_DECLTYPES)
        conn.row_factory = sqlite3.Row
        # IMPORTANT: ensure FK constraints & triggers fire per connection. :contentReference[oaicite:3]{index=3}
        conn.execute("PRAGMA foreign_keys = ON")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _insert(self, table: str, data: Dict[str, Any]) -> int:
        keys = ", ".join(data.keys())
        placeholders = ", ".join(f":{k}" for k in data)
        sql = f"INSERT INTO {table} ({keys}) VALUES ({placeholders})"
        with self._connect() as conn:
            cur = conn.execute(sql, data)
            return cur.lastrowid

    def _select_one(self, table: str, pk_name: str, pk_value: Any):
        sql = f"SELECT * FROM {table} WHERE {pk_name} = ?"
        with self._connect() as conn:
            cur = conn.execute(sql, (pk_value,))
            return cur.fetchone()

    def _select_many(self, table: str, where_clause: str = "", params: Sequence[Any] = ()):
        sql = f"SELECT * FROM {table} {where_clause}"
        with self._connect() as conn:
            cur = conn.execute(sql, params)
            return cur.fetchall()

    def _columns(self, table: str) -> set[str]:
        with self._connect() as conn:
            cur = conn.execute(f"PRAGMA table_info({table})")
            return {row["name"] for row in cur.fetchall()}

    def _update(self, table: str, pk_name: str, pk_value: Any, updates: Dict[str, Any]):
        if not updates:
            return
        if "updated_at" in self._columns(table):
            updates.setdefault("updated_at", _current_ts())
        set_clause = ", ".join(f"{k} = :{k}" for k in updates)
        updates[pk_name] = pk_value
        sql = f"UPDATE {table} SET {set_clause} WHERE {pk_name} = :{pk_name}"
        with self._connect() as conn:
            conn.execute(sql, updates)

    def _delete(self, table: str, pk_name: str, pk_value: Any):
        sql = f"DELETE FROM {table} WHERE {pk_name} = ?"
        with self._connect() as conn:
            conn.execute(sql, (pk_value,))

# -----------------------------------------------------------------------------
# CRUD classes (as documented in your thesis) :contentReference[oaicite:4]{index=4}
# -----------------------------------------------------------------------------
class CRUDBase:
    def __init__(self, db: CRMDatabase, table: str, pk: str | None = None):
        self.db = db
        self.table = table
        self.pk = pk

    def get(self, pk):
        return self.db._select_one(self.table, self.pk, pk)

    def list(self, where="", params=()):
        return [dict(r) for r in self.db._select_many(self.table, where, params)]

    def create(self, data):
        return self.db._insert(self.table, data)

    def update(self, pk, data):
        self.db._update(self.table, self.pk, pk, data)

    def delete(self, pk):
        self.db._delete(self.table, self.pk, pk)

class VendorCRUD(CRUDBase):
    def __init__(self, db):
        super().__init__(db, "vendors", "vendor_id")
class VendorContactCRUD(CRUDBase):
    def __init__(self, db):
        super().__init__(db, "vendor_contacts", "contact_id")
class VendorScorecardCRUD(CRUDBase):
    def __init__(self, db):
        super().__init__(db, "vendor_scorecard", "scorecard_id")
class ContractCRUD(CRUDBase):
    def __init__(self, db):
        super().__init__(db, "contracts", "contract_id")
class PipelineCRUD(CRUDBase):
    def __init__(self, db):
        super().__init__(db, "pipelines", "pipeline_id")
class PipelineStageCRUD(CRUDBase):
    def __init__(self, db):
        super().__init__(db, "pipeline_stages", "stage_id")
class OpportunityTaskTicketCRUD(CRUDBase):
    def __init__(self, db):
        super().__init__(db, "opportunities_task_tickets", "opportunity_id")
class PropertiesCRUD(CRUDBase):
    def __init__(self, db):
        super().__init__(db, "properties", "property_id")
class DocumentsCRUD(CRUDBase):
    def __init__(self, db):
        super().__init__(db, "documents", "document_id")
class CommunicationsCRUD(CRUDBase):
    def __init__(self, db):
        super().__init__(db, "communications", "communication_id")
class OwnerCRUD(CRUDBase):
    def __init__(self, db):
        super().__init__(db, "owner", "owner_id")
class OwnerPropertyMapCRUD(CRUDBase):
    def __init__(self, db):
        super().__init__(db, "owner_property_map", "map_id")

db = CRMDatabase("./airbnb.db")
entities = {
    "vendors": VendorCRUD(db),
    "vendor_contacts": VendorContactCRUD(db),
    "vendor_scorecard": VendorScorecardCRUD(db),
    "contracts": ContractCRUD(db),
    "pipelines": PipelineCRUD(db),
    "pipeline_stages": PipelineStageCRUD(db),
    "opportunities_task_ticket": OpportunityTaskTicketCRUD(db),  # route key kept
    "properties": PropertiesCRUD(db),
    "documents": DocumentsCRUD(db),
    "communications": CommunicationsCRUD(db),
    "owner": OwnerCRUD(db),
    "owner_property_map": OwnerPropertyMapCRUD(db),
}

# -----------------------------------------------------------------------------
# Route factory (now wrapped with @handle_db_errors) — same shape as before. :contentReference[oaicite:5]{index=5}
# -----------------------------------------------------------------------------
def _register_entity_routes(entity: str, crud: CRUDBase):
    validator_cls, pk_field = VALIDATORS[entity]
    base_path = f"/{entity}/"

    @app.post(base_path)
    @auth_required
    @admin_only
    @handle_db_errors
    def _create():
        data = request.json
        if not data:
            response.status = 400
            return {"error": "Missing JSON payload"}
        err = _run_validation(validator_cls, data, partial=False)
        if err:
            return err
        new_id = crud.create(data)
        response.status = 201
        return {"insertStatus": True, pk_field: new_id}

    @app.get(f"{base_path}<id_start>/<id_end>/")
    @auth_required
    @handle_db_errors
    def _read(id_start, id_end):
        rows = crud.list(f"WHERE {pk_field} BETWEEN ? AND ?", (id_start, id_end))
        return {"data": rows}

    @app.put(base_path)
    @auth_required
    @admin_only
    @handle_db_errors
    def _update():
        data = request.json
        if not data or pk_field not in data:
            response.status = 400
            return {"error": f"Missing {pk_field} or payload"}
        pk = data.pop(pk_field)
        err = _run_validation(validator_cls, data, partial=True)
        if err:
            return err
        crud.update(pk, data)
        return {"updateStatus": True}

    @app.delete(base_path)
    @auth_required
    @admin_only
    @handle_db_errors
    def _delete():
        data = request.json
        if not data or pk_field not in data:
            response.status = 400
            return {"error": f"Missing {pk_field}"}
        crud.delete(data[pk_field])
        return {"deleteStatus": True}

# Register all entity routes
for name, crud in entities.items():
    _register_entity_routes(name, crud)

@app.post('/refresh')
def refresh():
    rt = request.get_cookie('refresh_token') or ''
    payload = decode_token(rt)
    if not payload:
        response.status = 401
        return {"error": "Invalid refresh token"}
    access = generate_token(payload['username'], payload.get('role','user'))
    secure_flag = (request.urlparts.scheme == 'https')
    response.set_cookie('access_token', access, httponly=True, path='/', samesite='lax', secure=secure_flag)
    return {"ok": True}

@app.get('/me')
@auth_required
def me():
    h = request.get_header('Authorization') or ''
    token = h.split(' ',1)[1] if h.startswith('Bearer ') else request.get_cookie('access_token')
    payload = decode_token(token)
    return {"user": {"username": payload.get('username'), "role": payload.get('role')}}


# -----------------------------------------------------------------------------
# Run server
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    #run(app, host="localhost", port=8000, debug=True)

    #one of either:
    serve_https(app)

    #B: (optional) redirector at 80+https at 8000
    """

    import threading
    t = threading.Thread(target=serve_https, args=(app,), daemon=True)
    t.start()
    serve_http_redirect()
    """