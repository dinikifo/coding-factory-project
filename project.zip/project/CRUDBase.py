class CRUDBase(ABC):
    def __init__(self, db: CRMDatabase, table: str):
        self.db = db
        self.table = table

    @abstractmethod
    def get(self, pk: int) -> Optional[Dict[str, Any]]:
        pass

    @abstractmethod
    def list(self, where: str = "", params: Sequence[Any] = ()) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    def create(self, data: Dict[str, Any]) -> int:
        pass

    @abstractmethod
    def update(self, pk: int, data: Dict[str, Any]) -> None:
        pass

    @abstractmethod
    def delete(self, pk: int) -> None:
        pass