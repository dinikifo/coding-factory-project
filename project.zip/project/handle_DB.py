"""
Light‑weight CRUD helper for Airbnb Vendor CRM schema in **SQLite**.

Changes in this revision (2025‑06‑26)
------------------------------------
* **Automatic timestamps** – `created_at` is always filled on insert, `updated_at` every time you update a row.  This avoids `NOT NULL` integrity errors when the table requires those columns but no DB‑level default was declared.
* Centralised `_current_ts()` returning an ISO‑8601 UTC string (e.g. `2025‑06‑26T12:34:56Z`).
* `update_*` helpers now write `updated_at` transparently (unless you explicitly pass one).
* Minor docs / type‑hint tweaks.

Assumptions
-----------
* Tables exist exactly as defined in your schema.
* Tables that need timestamps follow the conventional column names `created_at` and `updated_at`.
* Primary key column ends with `_id`.
* All datetime values are stored as ISO‑8601 UTC strings.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Sequence

__all__ = ["CRMDatabase"]


def _current_ts() -> str:  # ISO‑8601, UTC, second precision
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


class CRMDatabase:
    """High‑level wrapper around :pymod:`sqlite3` exposing convenient CRUD helpers
    for the main CRM tables (vendors, contacts, contracts, pipelines, stages, opportunities).
    """

    def __init__(self, db_path: str):
        self.db_path = db_path

    # ------------------------------------------------------------------
    # Connection helpers
    # ------------------------------------------------------------------
    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.db_path, detect_types=sqlite3.PARSE_DECLTYPES)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:  # pragma: no cover – re‑raise after rollback
            conn.rollback()
            raise
        finally:
            conn.close()

    # ------------------------------------------------------------------
    # Generic SQL helpers
    # ------------------------------------------------------------------
    def _insert(self, table: str, data: Dict[str, Any]) -> int:
        # Auto‑fill created_at/updated_at if they are not provided.
        if "created_at" not in data:
            data["created_at"] = _current_ts()
        if "updated_at" not in data and "updated_at" in data.keys():
            # Only set if caller intends to write updated_at (rare on INSERT)
            data.setdefault("updated_at", _current_ts())

        keys = ", ".join(data.keys())
        placeholders = ", ".join(f":{k}" for k in data.keys())
        sql = f"INSERT INTO {table} ({keys}) VALUES ({placeholders})"
        with self._connect() as conn:
            cur = conn.execute(sql, data)
            return cur.lastrowid

    def _select_one(self, table: str, pk_name: str, pk_value: Any):
        sql = f"SELECT * FROM {table} WHERE {pk_name} = ?"
        with self._connect() as conn:
            cur = conn.execute(sql, (pk_value,))
            return cur.fetchone()

    def _select_many(
        self, table: str, where_clause: str = "", params: Sequence[Any] = ()
    ):
        sql = f"SELECT * FROM {table} {where_clause}"
        with self._connect() as conn:
            cur = conn.execute(sql, params)
            return cur.fetchall()

    def _update(
        self, table: str, pk_name: str, pk_value: Any, updates: Dict[str, Any]
    ) -> None:
        if not updates:
            return
        # Auto timestamp
        updates.setdefault("updated_at", _current_ts())

        set_clause = ", ".join(f"{k} = :{k}" for k in updates)
        updates[pk_name] = pk_value
        sql = f"UPDATE {table} SET {set_clause} WHERE {pk_name} = :{pk_name}"
        with self._connect() as conn:
            conn.execute(sql, updates)

    def _delete(self, table: str, pk_name: str, pk_value: Any):
        sql = f"DELETE FROM {table} WHERE {pk_name} = ?"
        with self._connect() as conn:
            conn.execute(sql, (pk_value,))

    # ------------------------------------------------------------------
    # CRUD – communications
    # ------------------------------------------------------------------
    def create_communications(self, **data) -> int:
        return self._insert("communications", data)

    def get_communications(self, vendor_id: int):
        return self._select_one("communications", "communication_id", vendor_id)

    def list_communications(self, where: str = "", params: Sequence[Any] = ()):  # noqa: D401
        return self._select_many("communications", where, params)

    def update_communications(self, vendor_id: int, **updates):
        self._update("communications", "communication_id", vendor_id, updates)

    def delete_communications(self, vendor_id: int):
        self._delete("communications", "communication_id", vendor_id)

    # ------------------------------------------------------------------
    # CRUD – Vendors
    # ------------------------------------------------------------------
    def create_vendor(self, **data) -> int:
        return self._insert("vendors", data)

    def get_vendor(self, vendor_id: int):
        return self._select_one("vendors", "vendor_id", vendor_id)

    def list_vendors(self, where: str = "", params: Sequence[Any] = ()):  # noqa: D401
        return self._select_many("vendors", where, params)

    def update_vendor(self, vendor_id: int, **updates):
        self._update("vendors", "vendor_id", vendor_id, updates)

    def delete_vendor(self, vendor_id: int):
        self._delete("vendors", "vendor_id", vendor_id)

    # ------------------------------------------------------------------
    # CRUD – Vendor Contacts
    # ------------------------------------------------------------------
    def create_vendor_contact(self, **data) -> int:
        return self._insert("vendor_contacts", data)

    def get_vendor_contact(self, contact_id: int):
        return self._select_one("vendor_contacts", "contact_id", contact_id)

    def list_vendor_contacts(self, vendor_id: Optional[int] = None):
        if vendor_id:
            return self._select_many(
                "vendor_contacts", "WHERE vendor_id = ?", (vendor_id,)
            )
        return self._select_many("vendor_contacts")

    def update_vendor_contact(self, contact_id: int, **updates):
        self._update("vendor_contacts", "contact_id", contact_id, updates)

    def delete_vendor_contact(self, contact_id: int):
        self._delete("vendor_contacts", "contact_id", contact_id)

    # ------------------------------------------------------------------
    # CRUD – Contracts
    # ------------------------------------------------------------------
    def create_contract(self, **data) -> int:
        return self._insert("contracts", data)

    def get_contract(self, contract_id: int):
        return self._select_one("contracts", "contract_id", contract_id)

    def list_contracts(self, vendor_id: Optional[int] = None):
        if vendor_id:
            return self._select_many(
                "contracts", "WHERE vendor_id = ?", (vendor_id,)
            )
        return self._select_many("contracts")

    def update_contract(self, contract_id: int, **updates):
        self._update("contracts", "contract_id", contract_id, updates)

    def delete_contract(self, contract_id: int):
        self._delete("contracts", "contract_id", contract_id)

    # ------------------------------------------------------------------
    # CRUD – Pipelines
    # ------------------------------------------------------------------
    def create_pipeline(self, **data) -> int:
        return self._insert("pipelines", data)

    def get_pipeline(self, pipeline_id: int):
        return self._select_one("pipelines", "pipeline_id", pipeline_id)

    def list_pipelines(self):
        return self._select_many("pipelines")

    def update_pipeline(self, pipeline_id: int, **updates):
        self._update("pipelines", "pipeline_id", pipeline_id, updates)

    def delete_pipeline(self, pipeline_id: int):
        self._delete("pipelines", "pipeline_id", pipeline_id)

    # ------------------------------------------------------------------
    # CRUD – Pipeline Stages
    # ------------------------------------------------------------------
    def create_pipeline_stage(self, **data) -> int:
        return self._insert("pipeline_stages", data)

    def get_pipeline_stage(self, stage_id: int):
        return self._select_one("pipeline_stages", "stage_id", stage_id)

    def list_pipeline_stages(self, pipeline_id: Optional[int] = None):
        if pipeline_id:
            return self._select_many(
                "pipeline_stages",
                "WHERE pipeline_id = ? ORDER BY stage_order",
                (pipeline_id,),
            )
        return self._select_many("pipeline_stages")

    def update_pipeline_stage(self, stage_id: int, **updates):
        self._update("pipeline_stages", "stage_id", stage_id, updates)

    def delete_pipeline_stage(self, stage_id: int):
        self._delete("pipeline_stages", "stage_id", stage_id)

    # ------------------------------------------------------------------
    # CRUD – Opportunities
    # ------------------------------------------------------------------
    def create_opportunity(self, **data) -> int:
        return self._insert("opportunities", data)

    def get_opportunity(self, opportunity_id: int):
        return self._select_one("opportunities", "opportunity_id", opportunity_id)

    def list_opportunities(
        self, where: str = "", params: Sequence[Any] = ()
    ):  # noqa: D401
        return self._select_many("opportunities", where, params)

    def update_opportunity(self, opportunity_id: int, **updates):
        self._update("opportunities", "opportunity_id", opportunity_id, updates)

    def delete_opportunity(self, opportunity_id: int):
        self._delete("opportunities", "opportunity_id", opportunity_id)

    # ------------------------------------------------------------------
    # High‑level helper
    # ------------------------------------------------------------------
    def move_opportunity_stage(self, opportunity_id: int, new_stage_id: int):
        """Shortcut to move an opportunity to a new stage."""
        self.update_opportunity(opportunity_id, stage_id=new_stage_id)


# ----------------------------------------------------------------------
# Quick‑start demo (remove or adapt in production)
# ----------------------------------------------------------------------
if __name__ == "__main__":
    db = CRMDatabase("./airbnb.db")

    vendor_id = db.create_vendor(
        name="CleanCo Services",
        vendor_type="Cleaning Service",
        status="ACTIVE",
        phone="+1‑555‑0000",
        email="contact@cleanco.io",
        address="10 Market Street",
        created_at="31.01.2020",
        updated_at="31.01.2020"
    )
    print("Created vendor:", vendor_id)

    vendor = db.get_vendor(vendor_id)
    print(dict(vendor))

    db.update_vendor(vendor_id, phone="+1‑555‑7890")
