// app.js — unified SPA logic (index + create-update + pipelines), aligned with APP_MAIN.7.py


// ---------------- Config ----------------
const REFRESH_ENABLED = false; // backend has no /refresh
// Treat both HTTP/HTTPS on localhost:8000 as same-origin
const SAME_ORIGIN = /^(https?:)\/\/(localhost|127\.0\.0\.1):8000$/.test(location.origin);

// When the page is served by the Bottle app (same origin), use relative paths.
// If you must point to a running backend explicitly, use HTTPS now.
const API_BASE = SAME_ORIGIN ? "" : "https://localhost:8000";

const ENTITIES = [
  "vendors","vendor_contacts","vendor_scorecard","contracts","pipelines","pipeline_stages",
  "opportunities_task_ticket","properties","documents","communications","owner","owner_property_map"
];
const PK = {
  vendors:"vendor_id", vendor_contacts:"contact_id", vendor_scorecard:"scorecard_id",
  contracts:"contract_id", pipelines:"pipeline_id", pipeline_stages:"stage_id",
  opportunities_task_ticket:"opportunity_id", properties:"property_id", documents:"document_id",
  communications:"communication_id", owner:"owner_id", owner_property_map:"map_id"
};

// Minimal field hints (extend as needed)
const FIELDS = {
  vendors: [
    {name:"name"}, {name:"vendor_type"}, {name:"status"},
    {name:"phone"}, {name:"email", type:"email"}, {name:"address"}
  ],
  vendor_contacts: [
    {name:"vendor_id", type:"number"}, {name:"first_name"}, {name:"last_name"},
    {name:"job_title"}, {name:"phone"}, {name:"email", type:"email"}
  ],
  vendor_scorecard: [
    {name:"vendor_id", type:"number"}, {name:"period_start", type:"date"},
    {name:"period_end", type:"date"}, {name:"quality_score", type:"number", step:"0.01"},
    {name:"on_time_delivery", type:"number", step:"0.01"}, {name:"defect_rate", type:"number", step:"0.01"},
    {name:"comments", type:"textarea"}
  ],
  contracts: [
    {name:"vendor_id", type:"number"}, {name:"contract_name"},
    {name:"start_date", type:"date"}, {name:"end_date", type:"date"},
    {name:"amount", type:"number", step:"0.01"}
  ],
  documents: [
    {name:"contract_id", type:"number"}, {name:"title"}, {name:"file_path"}
  ],
  pipelines: [{name:"pipeline_name"}, {name:"description"}],
  pipeline_stages: [
    {name:"pipeline_id", type:"number"}, {name:"stage_name"}, {name:"stage_order", type:"number"}
  ],
  opportunities_task_ticket: [
    {name:"pipeline_id", type:"number"}, {name:"title"}, {name:"due_date", type:"date"},
    {name:"status"}
  ],
  properties: [
    {name:"name"}, {name:"address"}, {name:"city"}, {name:"state"}, {name:"postal_code"},
    {name:"country"}, {name:"status"}
  ],
  communications: [
    {name:"vendor_id", type:"number"}, {name:"date_sent", type:"date"},
    {name:"comm_type"}, {name:"subject"}, {name:"content", type:"textarea"},
    {name:"followup_needed"}
  ],
  owner: [
    {name:"first_name"}, {name:"last_name"}, {name:"email", type:"email"},
    {name:"phone"}, {name:"address"}, {name:"legal_id"}
  ],
  owner_property_map: [
    {name:"owner_id", type:"number"}, {name:"property_id", type:"number"}
  ]
};

// ---------------- Utilities ----------------
function $(id){ return document.getElementById(id); }

function getCookie(name){
  if (!document.cookie) return null;
  const parts = document.cookie.split("; ");
  for (let i=0;i<parts.length;i++){
    const part = parts[i];
    const eq = part.indexOf("=");
    let k, v;
    if (eq === -1){ k = decodeURIComponent(part); v = ""; }
    else { k = decodeURIComponent(part.slice(0, eq)); v = decodeURIComponent(part.slice(eq+1)); }
    if (k === name) return v;
  }
  return null;
}

function isWrite(m){ return ["POST","PUT","PATCH","DELETE"].includes(String(m||"GET").toUpperCase()); }
function todayDMY(){
  const d = new Date();
  const dd = String(d.getDate()).padStart(2,"0");
  const mm = String(d.getMonth()+1).padStart(2,"0");
  const yy = d.getFullYear();
  return dd + "." + mm + "." + yy;
}
function isoToDMY(s){
  if (!s || s.indexOf("-") === -1) return s;
  const parts = s.split("-");
  if (parts.length !== 3) return s;
  return parts[2].padStart(2,"0") + "." + parts[1].padStart(2,"0") + "." + parts[0];
}

// ---------------- Core fetch ----------------
async function apiFetch(path, opts={}, _retried=false){
  const url = (typeof path === "string" && path.startsWith("http")) ? path : API_BASE + path;
  const method = String(opts.method || "GET").toUpperCase();
  const headers = new Headers(opts.headers || {});

  // Add CSRF on writes, but NOT for /login or /refresh
  const pathOnly = typeof path === "string" ? path.split("?")[0] : "";
  const skipCsrf = pathOnly === "/login" || pathOnly === "/refresh";
  if (isWrite(method) && !skipCsrf) headers.set("X-CSRF-Token", getCookie("X-CSRF-Token") || "");

  // Normalize JSON body & headers
  let body = opts.body;
  if (body && typeof body === "object" && !(body instanceof FormData)){
    if (!headers.has("Content-Type")) headers.set("Content-Type","application/json");
    body = JSON.stringify(body);
  } else if (typeof body === "string"){
    if (!headers.has("Content-Type")) headers.set("Content-Type","application/json");
  }

  const res = await fetch(url, { ...opts, method, headers, credentials:"include", body });
  // Only attempt refresh if enabled and a refresh cookie exists
  if (res.status === 401 && !_retried && REFRESH_ENABLED && getCookie("refresh_token")){
    const rr = await fetch(API_BASE + "/refresh", { method:"POST", credentials:"include" });
    if (rr.ok) return apiFetch(path, opts, true);
  }
  return res;
}

// ---------------- Auth helpers (GLOBAL) ----------------
async function me(){ const r = await apiFetch("/me"); return r.ok ? r.json() : null; }
async function login(username, password){
  const r = await apiFetch("/login", { method:"POST", body: { username, password } });
  if (!r.ok){
    const txt = await r.text().catch(()=>"");
    const msg = txt ? `Login failed (status ${r.status}): ${txt}` : `Login failed (status ${r.status})`;
    throw new Error(msg);
  }
  return r.json().catch(() => ({}));
}
async function logout(){ return apiFetch("/logout", { method:"POST" }); }

// ---------------- CRUD helpers ----------------
async function fetchRange(entity, start, end){
  const r = await apiFetch("/" + entity + "/" + start + "/" + end + "/");
  return r.json();
}
async function createRecord(entity, payload){
  const stamp = todayDMY();
  if (entity === "documents" && !payload.uploaded_at) payload.uploaded_at = stamp;
  if (!payload.created_at) payload.created_at = stamp;
  payload.updated_at = stamp;
  const r = await apiFetch("/" + entity + "/", { method:"POST", body: payload });
  return r.json();
}
async function updateRecord(entity, payload){
  payload.updated_at = todayDMY();
  const r = await apiFetch("/" + entity + "/", { method:"PUT", body: payload });
  return r.json();
}
async function deleteRecord(entity, id){
  const body = {}; body[PK[entity]] = id;
  const r = await apiFetch("/" + entity + "/", { method:"DELETE", body });
  return r.json();
}

// ---------------- UI builders ----------------
function populateEntitySelects(ids) {
  if (!Array.isArray(ids)) return;
  ids.forEach((ref) => {
    const sel = (typeof ref === "string") ? document.getElementById(ref) : ref;
    if (!sel) return;
    sel.innerHTML = ENTITIES.map(e => `<option value="${e}">${e}</option>`).join("");
  });
}
function renderFieldControl(field, value, requirePk){
  const type = field.type || "text";
  const id = "f-" + field.name;
  const label = field.label || field.name;
  const val = String(value == null ? "" : value).replace(/"/g,"&quot;");
  if (type === "textarea"){
    return '<div class="col-md-4"><label class="form-label" for="'+id+'">'+label+'</label>' +
           '<textarea id="'+id+'" name="'+field.name+'" class="form-control" rows="2">'+val+'</textarea></div>';
  }
  const extra = field.step ? ' step="'+field.step+'"' : "";
  const req = (requirePk && field.name === requirePk) ? " required" : "";
  return '<div class="col-md-3"><label class="form-label" for="'+id+'">'+label+'</label>' +
         '<input id="'+id+'" name="'+field.name+'" class="form-control" type="'+type+'"'+extra+req+' value="'+val+'" /></div>';
}
function buildForm(containerId, entity, mode){
  const el = $(containerId);
  const fields = (FIELDS[entity] || []).slice();
  if (mode === "update") fields.unshift({ name: PK[entity], type:"number", label: PK[entity] });
  let html = "";
  for (let i=0;i<fields.length;i++){ html += renderFieldControl(fields[i], "", (mode==="update") ? PK[entity] : null); }
  el.innerHTML = html;
}
function collectForm(containerId){
  const form = $(containerId);
  const nodes = form.querySelectorAll("input,textarea");
  const out = {};
  for (let i=0;i<nodes.length;i++){
    const n = nodes[i];
    const nm = n.name;
    let v = n.value;
    if (!v) continue;
    const t = n.getAttribute("type") || (n.tagName === "TEXTAREA" ? "textarea" : "text");
    if (t === "date") v = isoToDMY(v);
    else if (t === "number") v = Number(v);
    out[nm] = v;
  }
  return out;
}
function renderTable(holderId, rows){
  const holder = $(holderId);
  if (!rows || !rows.length){
    holder.innerHTML = '<div class="alert alert-warning">No records.</div>';
    return;
  }
  const cols = Object.keys(rows[0]);
  let thead = "<thead><tr>";
  for (let i=0;i<cols.length;i++){ thead += "<th>"+cols[i]+"</th>"; }
  thead += "</tr></thead>";
  let body = "";
  for (let r=0;r<rows.length;r++){
    const row = rows[r];
    body += "<tr>";
    for (let i=0;i<cols.length;i++){ const c = cols[i]; body += "<td>"+(row[c] == null ? "" : row[c])+"</td>"; }
    body += "</tr>";
  }
  holder.innerHTML = '<div class="table-responsive"><table class="table table-striped table-bordered">'+thead+"<tbody>"+body+"</tbody></table></div>";
}

// ---------------- Wire-up (index.html & create-update.html & pipelines.html) ----------------
window.addEventListener("DOMContentLoaded", async function(){
  // Detect create-update page
  const cuRoot = document.getElementById("page-create-update");
  if (cuRoot) {
    const who = document.getElementById("whoami");
    const logoutBtn = document.getElementById("btn-logout");
    if (logoutBtn) logoutBtn.addEventListener("click", async function(){ await logout(); location.href = "index.html"; });

    // Try to populate whoami (optional)
    try { const info = await me(); if (info && info.user && who) who.textContent = info.user.username + " (" + info.user.role + ")"; } catch(_){}

    const cuEntity = document.getElementById("cu-entity");
    if (cuEntity) { cuEntity.innerHTML = ENTITIES.map(e => '<option value="'+e+'">'+e+'</option>').join(""); }

    // Apply URL params (?mode=create|update&entity=...) to preselect UI
    const params = new URLSearchParams(location.search);
    const modeParam = (params.get('mode')||'').toLowerCase();
    if (modeParam === 'update') { const rb=document.getElementById('cu-mode-update'); if (rb) { rb.checked = true; } }
    if (modeParam === 'create') { const rb=document.getElementById('cu-mode-create'); if (rb) { rb.checked = true; } }
    const entityParam = params.get('entity');
    if (entityParam && ENTITIES.indexOf(entityParam) !== -1 && cuEntity) { cuEntity.value = entityParam; }

    function currentMode(){ return document.getElementById("cu-mode-update").checked ? "update" : "create"; }
    function rebuildForm(){
      const e = cuEntity.value;
      if (!e) { document.getElementById("cu-form").innerHTML = ""; return; }
      buildForm("cu-form", e, currentMode());
    }

    cuEntity && cuEntity.addEventListener("change", rebuildForm);
    const mCreate = document.getElementById("cu-mode-create");
    const mUpdate = document.getElementById("cu-mode-update");
    mCreate && mCreate.addEventListener("change", rebuildForm);
    mUpdate && mUpdate.addEventListener("change", rebuildForm);

    const cuSubmit = document.getElementById("cu-submit");
    cuSubmit && cuSubmit.addEventListener("click", async function(){
      const e = cuEntity.value;
      if (!e) return;
      const mode = currentMode();
      const payload = collectForm("cu-form");
      const outEl = document.getElementById("cu-out");
      outEl.textContent = "";
      try {
        let res;
        if (mode === "create") {
          res = await createRecord(e, payload);
        } else {
          if (!payload[PK[e]]) { alert("Missing "+PK[e]); return; }
          res = await updateRecord(e, payload);
        }
        outEl.textContent = JSON.stringify(res, null, 2);
      } catch (err) {
        outEl.textContent = "Error: " + (err && err.message ? err.message : String(err));
      }
    });

    // Initial form
    rebuildForm();
    return; // stop here for this page
  }

  // Detect pipelines page
  const plRoot = document.getElementById("page-pipelines");
  if (plRoot) {
    const who = document.getElementById("whoami");
    const logoutBtn = document.getElementById("btn-logout");
    if (logoutBtn) logoutBtn.addEventListener("click", async function(){ await logout(); location.href = "index.html"; });

    // Try to populate whoami (optional)
    try { const info = await me(); if (info && info.user && who) who.textContent = info.user.username + " (" + info.user.role + ")"; } catch(_){}

    // Helpers
    const logEl = document.getElementById('log');
    function log(msg){ logEl.textContent += msg + "\n"; logEl.scrollTop = logEl.scrollHeight; }

    function addStageRow(name) {
      const container = document.getElementById('stagesContainer');
      if (!container) return;
      const index = container.children.length + 1;
      const row = document.createElement('div');
      row.className = 'stage-row input-group';
      const safe = (name || '').replace(/"/g,'&quot;');
      row.innerHTML = '<span class="input-group-text">'+index+'</span>' +
                      '<input class="form-control stage-name" placeholder="Stage Name" value="'+safe+'">' +
                      '<button class="btn btn-outline-danger" type="button" aria-label="Remove">&times;</button>';
      row.querySelector('button').onclick = function(){ row.remove(); renumberStages(); toggleCreateEnabled(); };
      container.appendChild(row);
      toggleCreateEnabled();
    }
    function renumberStages(){
      const container = document.getElementById('stagesContainer');
      Array.prototype.forEach.call(container.children, function(row, i){
        row.querySelector('.input-group-text').textContent = i+1;
      });
    }
    function collectStageNames(){
      const nodes = document.querySelectorAll('.stage-name');
      const out = [];
      for (let i=0;i<nodes.length;i++){
        const v = nodes[i].value.trim();
        if (v) out.push(v);
      }
      return out;
    }
    function toggleCreateEnabled(){
      const plName = document.getElementById('plName').value.trim();
      const stagesOk = collectStageNames().length > 0;
      document.getElementById('createPipelineBtn').disabled = !(plName && stagesOk);
    }
    function today(){ const d = new Date(); return String(d.getDate()).padStart(2,'0') + '.' + String(d.getMonth()+1).padStart(2,'0') + '.' + d.getFullYear(); }

    // Wire buttons
    const addStageBtn = document.getElementById('addStageBtn');
    const clearStagesBtn = document.getElementById('clearStagesBtn');
    const resetManualBtn = document.getElementById('resetManual');
    const createBtn = document.getElementById('createPipelineBtn');
    const plNameInput = document.getElementById('plName');
    addStageBtn && addStageBtn.addEventListener('click', function(){ addStageRow(''); });
    clearStagesBtn && clearStagesBtn.addEventListener('click', function(){ document.getElementById('stagesContainer').innerHTML=''; toggleCreateEnabled(); });
    resetManualBtn && resetManualBtn.addEventListener('click', function(){
      document.getElementById('plName').value='';
      document.getElementById('plDesc').value='';
      document.getElementById('stagesContainer').innerHTML='';
      document.getElementById('createPipelineBtn').disabled = true;
    });
    plNameInput && plNameInput.addEventListener('input', toggleCreateEnabled);

    createBtn && createBtn.addEventListener('click', async function(){
      const name = document.getElementById('plName').value.trim();
      const desc = document.getElementById('plDesc').value.trim() || name;
      const stages = collectStageNames();
      if (!name || stages.length === 0){ log('Pipeline name & at least one stage required.'); return; }
      const stamp = today();
      try {
        log('Creating pipeline: ' + name);
        const pl = await createRecord('pipelines', { pipeline_name: name, description: desc, created_at: stamp, updated_at: stamp });
        const pipeline_id = pl.pipeline_id || pl.id || pl.data && pl.data.pipeline_id;
        log('Pipeline created (id=' + pipeline_id + ')');
        for (let i=0;i<stages.length;i++){
          const st = await createRecord('pipeline_stages', { pipeline_id: pipeline_id, stage_name: stages[i], stage_order: i+1, created_at: stamp, updated_at: stamp });
          log('  Stage inserted: ' + stages[i]);
        }
      } catch (err) {
        log('Error: ' + (err && err.message ? err.message : String(err)));
      }
    });

    // Reference pipelines
    const referencePipelines = [
      { name: 'General Task Management Pipeline', sampleTitle: 'Kickoff: triage new tasks', stages: ['New Task','Assigned','In Progress','Completed','Closed & Billed'] },
      { name: 'Cleaning Pipeline (Turnover Management)', sampleTitle: 'Schedule upcoming turnover', stages: ['Booking Confirmed','Cleaning Scheduled','Cleaning in Progress','Inspection Completed','Ready for Guest'] },
      { name: 'Maintenance Pipeline', sampleTitle: 'Review open maintenance tickets', stages: ['Maintenance Ticket Created','Assigned to Vendor','In Progress','Awaiting Parts','Completed','Closed & Billed'] },
      { name: 'Supply & Inventory Management Pipeline', sampleTitle: 'Reconcile supply inventory', stages: ['Reorder Needed','Order Placed','Order Shipped','Order Received','Inventory Updated'] },
      { name: 'Vendor Onboarding & Contract Management Pipeline', sampleTitle: 'Onboard new vendor', stages: ['Sourcing New Vendor','Vendor Evaluation','Contract Negotiation','Contract Signed','Active Vendor','Review & Renewal'] },
      { name: 'Property Acquisition Pipeline', sampleTitle: 'Evaluate property shortlist', stages: ['Property Identified','Under Contract','Due Diligence & Inspections','Purchase Finalized','Ready for Operations'] },
      { name: 'Guest Booking & Reservation Management Pipeline', sampleTitle: 'Confirm upcoming reservations', stages: ['Inquiry Received','Reservation Pending','Reservation Confirmed','Pre-Check-In Communication Sent','Check-In Completed','Stay Completed','Post-Stay Follow-Up Sent'] },
      { name: 'Marketing & Advertising Pipeline', sampleTitle: 'Plan next campaign', stages: ['Campaign Idea Generated','Campaign Plan Approved','Content Creation in Progress','Campaign Launched','Campaign Performance Analyzed','Campaign Closed'] },
      { name: 'Contract & Legal Compliance Pipeline', sampleTitle: 'Run compliance checklist', stages: ['Compliance Review Needed','Legal Review in Progress','Documents Submitted','Approval Pending','Compliance Approved'] },
      { name: 'Financial Management & Expense Tracking Pipeline', sampleTitle: 'Reconcile invoices', stages: ['Invoice Received','Payment Scheduled','Payment Processed','Expense Reconciled','Report Generated'] },
      { name: 'Property Maintenance & Renovation Projects Pipeline', sampleTitle: 'Define renovation scope', stages: ['Project Idea Created','Budget Approved','Vendor Assigned','Work In Progress','Inspection Completed','Project Closed'] },
      { name: 'Vendor Evaluation & Performance Review Pipeline', sampleTitle: 'Schedule vendor review', stages: ['Evaluation Scheduled','Vendor Data Collected','Review Conducted','Performance Scored','Contract Renewed/Terminated'] },
      { name: 'Emergency Response & Incident Management Pipeline', sampleTitle: 'Review incident report', stages: ['Incident Reported','Emergency Vendor Assigned','Issue Being Resolved','Follow-Up Inspection','Incident Closed'] },
      { name: 'Long-Term Expansion & Portfolio Growth Pipeline', sampleTitle: 'Analyze growth markets', stages: ['Market Research Completed','Potential Property Identified','Investment Approved','Property Acquired','Property Onboarded'] },
      { name: 'Crisis Management & Disaster Recovery Pipeline', sampleTitle: 'Draft incident response plan', stages: ['Incident Detected','Initial Assessment Completed','Emergency Response Activated','Vendors Assigned','Issue Resolved','Recovery & Post-Mortem Analysis'] },
      { name: 'Guest Complaint & Dispute Resolution Pipeline', sampleTitle: 'Triage guest complaints', stages: ['Complaint Received','Issue Investigated','Vendor/Team Assigned','Resolution Proposed','Resolution Accepted or Disputed','Case Closed'] },
      { name: 'Legal & Compliance Escalation Pipeline', sampleTitle: 'Escalate legal review', stages: ['Issue Identified','Legal Review Initiated','Documents & Evidence Collected','Legal Action Taken','Case Settled or Closed'] },
      { name: 'Insurance Claim & Damage Assessment Pipeline', sampleTitle: 'Open insurance claim', stages: ['Incident Reported','Insurance Company Notified','Assessment Scheduled','Claim Filed','Claim Approved or Denied','Claim Closed'] },
      { name: 'Security & Data Breach Response Pipeline', sampleTitle: 'Audit security incident', stages: ['Breach Detected','Investigation Launched','Security Vendor Assigned','Vulnerability Resolved','System Secured','Breach Closed'] },
      { name: 'Pandemic Response & Health Safety Pipeline', sampleTitle: 'Verify cleaning protocols', stages: ['Health Advisory Issued','Enhanced Cleaning Protocols Activated','Vendor Training Conducted','Health Inspection Scheduled','Compliance Verified','Operations Normalized'] },
      { name: 'Host Exit & Property Liquidation Pipeline', sampleTitle: 'Plan exit timeline', stages: ['Host Decision Received','Property Valuation Completed','Property Listed for Sale','Buyer Identified','Sale Finalized','Property Offboarded'] }
    ];

    const refList = document.getElementById('referenceList');
    const insertSelectedBtn = document.getElementById('insertSelectedBtn');

    function renderReferenceList(){
      refList.innerHTML = '';
      for (let i=0;i<referencePipelines.length;i++){
        const p = referencePipelines[i];
        const id = 'ref_' + i;
        refList.insertAdjacentHTML('beforeend',
          '<div class="form-check mb-2">' +
          '  <input class="form-check-input refCheck" type="checkbox" id="'+id+'">' +
          '  <label class="form-check-label" for="'+id+'">' +
          '    <strong>'+p.name+'</strong><br>' +
          '    <small>'+p.stages.join(' \u2192 ')+'</small>' +
          '  </label>' +
          '</div>'
        );
      }
    }
    function selectedReferences(){
      const boxes = document.querySelectorAll('.refCheck');
      const out = [];
      for (let i=0;i<boxes.length;i++){ if (boxes[i].checked) out.push(referencePipelines[i]); }
      return out;
    }
    function updateBulkButton(){ insertSelectedBtn.disabled = selectedReferences().length === 0; }
refList && refList.addEventListener('change', updateBulkButton);

    insertSelectedBtn && insertSelectedBtn.addEventListener('click', async function(){
      const chosen = selectedReferences();
      if (!chosen.length){ log('No pipelines selected.'); return; }
      const prefix = document.getElementById('optPrefixStages') ? document.getElementById('optPrefixStages').checked : false;
      const makeSample = document.getElementById('optSampleTicket') ? document.getElementById('optSampleTicket').checked : false;
      for (let k=0;k<chosen.length;k++){
        const p = chosen[k];
        const stamp = today();
        try {
          log('Bulk insert pipeline: ' + p.name);
          const pl = await createRecord('pipelines', { pipeline_name: p.name, description: p.name, created_at: stamp, updated_at: stamp });
          const pipeline_id = pl.pipeline_id || pl.id || pl.data && pl.data.pipeline_id;
          log('  Created id=' + pipeline_id);
          for (let i=0;i<p.stages.length;i++){
            const stageName = prefix ? ((i+1) + '. ' + p.stages[i]) : p.stages[i];
            await createRecord('pipeline_stages', { pipeline_id: pipeline_id, stage_name: stageName, stage_order: i+1, created_at: stamp, updated_at: stamp });
            log('    Stage inserted: ' + stageName);
          }
          if (makeSample){
            const title = p.sampleTitle || (p.name + ' kickoff');
            const ticket = await createRecord('opportunities_task_ticket', { pipeline_id: pipeline_id, title: title, status: 'open', created_at: stamp, updated_at: stamp });
            log('  Sample task created: ' + JSON.stringify(ticket));
          }
        } catch (err) {
          log('  Error: ' + (err && err.message ? err.message : String(err)));
        }
      }
    });

    // ---- Pipeline selection & ticket creation ----
    const selPipeline = document.getElementById('selPipeline');
    const selStage    = document.getElementById('selStage');
    const reloadPipelinesBtn = document.getElementById('reloadPipelines');
    const createTicketBtn = document.getElementById('createTicketBtn');
    const ticketTitle = document.getElementById('ticketTitle');
    const ticketDue   = document.getElementById('ticketDue');
    const ticketStatus= document.getElementById('ticketStatus');

    function setTicketEnabled(){
      const ok = selPipeline && selPipeline.value && selStage && selStage.value && ticketTitle && ticketTitle.value.trim();
      if (createTicketBtn) createTicketBtn.disabled = !ok;
    }

    async function loadPipelines(){
      try {
        const res = await fetchRange('pipelines', 1, 999999);
        const rows = (res && res.data) ? res.data : (Array.isArray(res) ? res : []);
        if (selPipeline){
          selPipeline.innerHTML = rows.map(r => {
            const id = r.pipeline_id || r.id;
            const name = r.pipeline_name || r.name || ('Pipeline ' + id);
            return '<option value="'+id+'">'+id+' — '+name+'</option>';
          }).join('');
        }
        await loadStagesForSelected();
        setTicketEnabled();
      } catch (err) {
        log('Error loading pipelines: ' + (err && err.message ? err.message : String(err)));
      }
    }

    async function loadStagesForSelected(){
      try {
        const res = await fetchRange('pipeline_stages', 1, 999999);
        const rows = (res && res.data) ? res.data : (Array.isArray(res) ? res : []);
        const pid = selPipeline ? Number(selPipeline.value) : null;
        const stages = rows.filter(r => Number(r.pipeline_id) === pid).sort((a,b)=> (a.stage_order||0)-(b.stage_order||0));
        if (selStage){
          selStage.innerHTML = stages.map(s => '<option value="'+(s.stage_id||s.id)+'">'+(s.stage_order||'')+'. '+(s.stage_name||'')+'</option>').join('');
        }
      } catch (err) {
        log('Error loading stages: ' + (err && err.message ? err.message : String(err)));
      }
    }

    selPipeline && selPipeline.addEventListener('change', async function(){ await loadStagesForSelected(); setTicketEnabled(); });
    selStage && selStage.addEventListener('change', setTicketEnabled);
    ticketTitle && ticketTitle.addEventListener('input', setTicketEnabled);
    reloadPipelinesBtn && reloadPipelinesBtn.addEventListener('click', loadPipelines);

    createTicketBtn && createTicketBtn.addEventListener('click', async function(){
      try {
        const pid = Number(selPipeline.value);
        const title = ticketTitle.value.trim();
        const due = ticketDue.value ? isoToDMY(ticketDue.value) : undefined;
        const status = ticketStatus.value.trim() || undefined;
        const payload = { pipeline_id: pid, title: title };
        if (due) payload.due_date = due;
        if (status) payload.status = status;
        const out = await createRecord('opportunities_task_ticket', payload);
        log('Ticket created: ' + JSON.stringify(out));
        ticketTitle.value = ''; ticketDue.value = ''; ticketStatus.value = '';
        setTicketEnabled();
      } catch (err) {
        log('Error creating ticket: ' + (err && err.message ? err.message : String(err)));
      }
    });


    // Render existing pipelines list (with stages)
    function renderCurrentPipelines(pipes, stages){
      const holder = document.getElementById('currentPipelines');
      if (!holder) return;
      if (!Array.isArray(pipes) || pipes.length === 0){
        holder.innerHTML = '<div class="text-muted">No pipelines found.</div>';
        return;
      }
      // Group stages by pipeline_id
      const byPid = {};
      (Array.isArray(stages) ? stages : []).forEach(function(s){
        const pid = Number(s.pipeline_id || s.pid || s.pipeline);
        if (!byPid[pid]) byPid[pid] = [];
        byPid[pid].push(s);
      });
      let html = '<div class="list-group">';
      pipes.forEach(function(p){
        const id = p.pipeline_id || p.id;
        const name = p.pipeline_name || p.name || ('Pipeline ' + id);
        const sList = (byPid[id] || []).sort(function(a,b){ return (a.stage_order||0) - (b.stage_order||0); });
        const chips = sList.map(function(s){ return '<span class="badge text-bg-light me-1 mb-1">'+(s.stage_order||'')+'. '+(s.stage_name||'')+'</span>'; }).join(' ');
        html += '<div class="list-group-item">'
              +   '<div class="d-flex justify-content-between align-items-center flex-wrap">'
              +     '<div><strong>'+id+'</strong> — '+name+'</div>'
              +     '<div class="small">'+chips+'</div>'
              +   '</div>'
              + '</div>';
      });
      html += '</div>';
      holder.innerHTML = html;
    }

        // Initial render for pipelines page
    renderReferenceList();
    updateBulkButton();
    if (document.getElementById('stagesContainer')) addStageRow(''); // one initial row
    // Load existing pipelines + stages for the sidebar list
    (async function(){
      try{
        const pr = await fetchRange('pipelines', 1, 999999);
        const sr = await fetchRange('pipeline_stages', 1, 999999);
        const pipes = (pr && (pr.data||pr.rows||pr.items||pr.records)) ? (pr.data||pr.rows||pr.items||pr.records) : (Array.isArray(pr)?pr:[]);
        const stages = (sr && (sr.data||sr.rows||sr.items||sr.records)) ? (sr.data||sr.rows||sr.items||sr.records) : (Array.isArray(sr)?sr:[]);
        renderCurrentPipelines(pipes, stages);
      }catch(e){ /* ignore */ }
    })();
    loadPipelines();

    return; // stop further SPA init
  }

  // Otherwise, initialize SPA (index.html)
  const existingIds = ["read-entity","create-entity","update-entity","delete-entity"].filter(id => document.getElementById(id));
  if (existingIds.length) populateEntitySelects(existingIds);

  // Default Read range if empty
  if (document.getElementById('read-start') && !document.getElementById('read-start').value) document.getElementById('read-start').value = 1;
  if (document.getElementById('read-end') && !document.getElementById('read-end').value) document.getElementById('read-end').value = 999999;

  const loginView = $("view-login");
  const appView   = $("view-app");
  const whoami    = $("whoami");
  const btnLogout = $("btn-logout");

  function showApp(userInfo){
    if (userInfo && userInfo.user) {
      whoami.textContent = userInfo.user.username + " (" + userInfo.user.role + ")";
    } else {
      whoami.textContent = "";
    }
    btnLogout && btnLogout.classList.remove("hidden");
    loginView && loginView.classList.add("hidden");
    appView && appView.classList.remove("hidden");
  }
  function showLogin(){
    if (!loginView || !appView || !btnLogout) return;
    whoami.textContent = "";
    btnLogout.classList.add("hidden");
    loginView.classList.remove("hidden");
    appView.classList.add("hidden");
  }

  
  // ---- Index Pipelines tab map ----
  async function renderPipelineMapIndex(holderId){
    const holder = document.getElementById(holderId);
    if (!holder) return;
    holder.textContent = "Loading…";
    try{
      const pr = await fetchRange('pipelines', 1, 999999);
      const sr = await fetchRange('pipeline_stages', 1, 999999);
      const pipes = (pr && (pr.data||pr.rows||pr.items||pr.records)) ? (pr.data||pr.rows||pr.items||pr.records) : (Array.isArray(pr)?pr:[]);
      const stages = (sr && (sr.data||sr.rows||sr.items||sr.records)) ? (sr.data||sr.rows||sr.items||sr.records) : (Array.isArray(sr)?sr:[]);
      // Build compact map
      if (!pipes.length){ holder.innerHTML = '<span class="text-muted">No pipelines found.</span>'; return; }
      const byPid = {};
      stages.forEach(function(s){ const pid = Number(s.pipeline_id||s.pid||s.pipeline); (byPid[pid] ||= []).push(s); });
      let html = '<div class="table-responsive"><table class="table table-sm align-middle"><thead><tr><th>ID</th><th>Name</th><th>Stages</th></tr></thead><tbody>';
      pipes.forEach(function(p){
        const id = p.pipeline_id || p.id;
        const name = p.pipeline_name || p.name || ('Pipeline ' + id);
        const sList = (byPid[id]||[]).sort(function(a,b){ return (a.stage_order||0)-(b.stage_order||0); });
        const chips = sList.map(function(s){ return '<span class="badge text-bg-light me-1 mb-1">'+(s.stage_order||'')+'. '+(s.stage_name||'')+'</span>'; }).join(' ');
        html += '<tr><td>'+id+'</td><td>'+name+'</td><td>'+chips+'</td></tr>';
      });
      html += '</tbody></table></div>';
      holder.innerHTML = html;
    }catch(err){
      holder.innerHTML = '<span class="text-danger">Failed to load pipelines map.</span>';
      console.error(err);
    }
  }
// Start in login view (align with tkcrm)
  if (loginView && appView) showLogin();

  // Login button
  if (document.getElementById("btn-login")) {
    document.getElementById("btn-login").addEventListener("click", async function(){
      $("login-msg").textContent = "";
      try{
        const u = $("login-username").value.trim();
        const p = $("login-password").value.trim();
        await login(u,p); // sets cookies incl. CSRF
        let info = null;
        try { info = await me(); } catch(_){ /* /me optional */ }
        showApp(info);
      }catch(err){
        $("login-msg").textContent = String(err && err.message ? err.message : err);
      }
    });
  }

  // Logout button
  if (btnLogout) {
    btnLogout.addEventListener("click", async function(){
      await logout();
      showLogin();
    });
  }

  // READ
  if (document.getElementById("btn-read")) {
    document.getElementById("btn-read").addEventListener("click", async function(){
      const e = $("read-entity").value;
      const s = $("read-start").value;
      const d = $("read-end").value;
      if (!e || !s || !d) return;
      $("read-out").innerHTML = "<div class='text-muted'>Loading…</div>";
      try{
        const res = await fetchRange(e, s, d);
        const rows = (res && (res.data || res.rows || res.result || res.items || res.records)) ?
                      (res.data || res.rows || res.result || res.items || res.records) :
                      (Array.isArray(res) ? res : []);
        renderTable("read-out", rows);
      }catch(err){
        $("read-out").innerHTML = '<div class="alert alert-danger">Error fetching data.</div>';
        console.error(err);
      }
    });
  }

  // CREATE
  if (document.getElementById("create-entity")) {
    document.getElementById("create-entity").addEventListener("change", function(){
      buildForm("create-form", $("create-entity").value, "create");
    });
    if (document.getElementById("btn-create")) {
      document.getElementById("btn-create").addEventListener("click", async function(){
        const e = $("create-entity").value;
        if (!e) return;
        const payload = collectForm("create-form");
        if (payload.uploaded_at) payload.uploaded_at = isoToDMY(payload.uploaded_at);
        try{
          const out = await createRecord(e, payload);
          $("create-out").textContent = JSON.stringify(out, null, 2);
        }catch(err){
          $("create-out").textContent = "Error creating record.";
          console.error(err);
        }
      });
    }
  }

  // UPDATE
  if (document.getElementById("update-entity")) {
    document.getElementById("update-entity").addEventListener("change", function(){
      buildForm("update-form", $("update-entity").value, "update");
    });
    if (document.getElementById("btn-update")) {
      document.getElementById("btn-update").addEventListener("click", async function(){
        const e = $("update-entity").value;
        if (!e) return;
        const payload = collectForm("update-form");
        if (!payload[PK[e]]){ alert("Missing " + PK[e]); return; }
        try{
          const out = await updateRecord(e, payload);
          $("update-out").textContent = JSON.stringify(out, null, 2);
        }catch(err){
          $("update-out").textContent = "Error updating record.";
          console.error(err);
        }
      });
    }
  }

  // DELETE
  if (document.getElementById("btn-delete")) {
    document.getElementById("btn-delete").addEventListener("click", async function(){
      const e = $("delete-entity").value;
      const id = $("delete-pk").value;
      if (!e || !id) return;
      try{
        const out = await deleteRecord(e, Number(id));
        $("delete-out").textContent = JSON.stringify(out, null, 2);
      }catch(err){
        $("delete-out").textContent = "Error deleting record.";
        console.error(err);
      }
    });
  }
});
